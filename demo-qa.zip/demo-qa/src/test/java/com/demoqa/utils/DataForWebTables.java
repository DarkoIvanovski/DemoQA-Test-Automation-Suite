package com.demoqa.utils;

import org.testng.annotations.DataProvider;

public class DataForWebTables {

    @DataProvider (name = "data-for-webtables")
    public Object [] [] dataForWebTables () {
        return new Object[][] {{"Emily", "Johnson", "emily.johnson@example.com", "28", "68000", "Marketing"},
                {"Michael", "Brown", "michael.brown@example.com", "35", "82500", "IT"},
                {"Sophia", "Williams", "sophia.williams@example.com", "31", "75200", "Human Resources"},
                {"James", "Miller", "james.miller@example.com", "42", "90300", "Finance"},
                {"Olivia", "Davis", "olivia.davis@example.com", "29", "70800", "Sales"},
                {"Daniel", "Anderson", "daniel.anderson@example.com", "38", "85400", "Operations"}
        };
    }
}
