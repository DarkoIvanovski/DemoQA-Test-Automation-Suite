package com.demoqa.utils;

import org.testng.annotations.DataProvider;

public class DataForTextBoxPage {
    @DataProvider (name="data-for-text-box-input")
    public Object [] [] dataTextBoxObject () {
        return new Object [][] {{"StarGazer42", "stargazer42@example.com", "123 Elm Street, Springfield, IL 62701", "789 Maple Avenue, Lincoln, NE 68508"},
                {"MoonWalker88", "moonwalker88@example.com", "456 Oak Street, Madison, WI 53703", "321 Pine Lane, Cedar Rapids, IA 52402"},
                {"OceanDreamer25", "oceandreamer25@example.com", "789 Birch Road, Boulder, CO 80302", "654 Willow Drive, Des Moines, IA 50309"}
        };
    }
}
