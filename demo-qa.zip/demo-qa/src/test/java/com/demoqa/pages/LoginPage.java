package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    WebDriver driver;
    WebDriverWait wait;

    public LoginPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String loginPageUrl = "https://demoqa.com/login";

    private By newUserButton = By.id("newUser");
    private By firstNameField = By.id("firstname");
    private By lastNameField = By.id("lastname");
    private By userNameField = By.id("userName");
    private By passwordField = By.id("password");
    private By registerButton = By.xpath("//button[@id='register']");
    private By backToLoginPage = By.id("gotologin");
    private By userNameLoginField = By.xpath("//input[@id='userName']");
    private By passwordLoginField = By.xpath("//input[@id='password']");
    private By loginButton = By.xpath("//button[@id='login']");
    private By userNameMessage = By.xpath("//label[@id='userName-value']");

    public void navigateToLoginPage () {
        driver.navigate().to(loginPageUrl);
    }

    public void clickOnNewUserButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(newUserButton)).click();
    }

    public void enterFirstName (String firstName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameField)).sendKeys(firstName);
    }

    public void enterLastName (String lastName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameField)).sendKeys(lastName);
    }

    public void enterUserName (String userName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(userNameField)).sendKeys(userName);
    }

    public void enterPassword (String password) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordField)).sendKeys(password);
    }

    public void clickOnRegisterButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(registerButton)).click();
    }

    public void clickOkOnPopupMessage () {
        driver.switchTo().alert().accept();
    }

    public void clickOnBackToLogin () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(backToLoginPage)).click();
    }

    public void enterLoginUserName (String loginUserName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(userNameLoginField)).sendKeys(loginUserName);
    }

    public void enterLoginPassword (String loginPassword) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(passwordLoginField)).sendKeys(loginPassword);
    }

    public void clickLogin () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginButton)).click();
    }

    public String getUserNameMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(userNameMessage)).getText();
    }

}
