package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ToolsTipPage {

    WebDriver driver;
    WebDriverWait wait;

    public ToolsTipPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String toolsTipPageUrl = "https://demoqa.com/tool-tips";

    private By toolsTipButton = By.id("toolTipButton");
    private By getButtonHoverMessage = By.xpath("//div[@id='buttonToolTip']/div[2]");
    private By toolTipField = By.id("toolTipTextField");
    private By fieldHoverMessage = By.xpath("//div[@id='textFieldToolTip']/div[2]");
    private By toolTipTextField = By.id("toolTipTextField");
    private By contraryLink = By.xpath("//div[@id='toopTipContainer']/div[3]/a");
    private By contraryHoverMessage = By.xpath("//div[@class='tooltip-inner']");


    public void navigateToToolsTipPage () {
        driver.navigate().to(toolsTipPageUrl);
    }

    public void overWithButton () throws InterruptedException {
        WebElement elementToHover = driver.findElement(toolsTipButton);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(1000);
    }

    public String getMessageWhenOverOnButton () throws InterruptedException {
        WebElement elementToHover = driver.findElement(toolsTipButton);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(3000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(getButtonHoverMessage)).getText();
    }

    public void overWithField () throws InterruptedException {
        WebElement elementToHover = driver.findElement(toolTipField);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(1000);
    }

    public String getMessageWhenOverOnField () throws InterruptedException {
        WebElement elementToHover = driver.findElement(toolTipField);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(3000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(fieldHoverMessage)).getText();
    }

    public void overWithText () throws InterruptedException {
        WebElement elementToHover = driver.findElement(contraryLink);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(3000);
    }

    public String getMessageWhenOverOnText () throws InterruptedException {
        WebElement elementToHover = driver.findElement(contraryLink);
        Actions actions = new Actions(driver);
        actions.moveToElement(elementToHover).perform();
        Thread.sleep(3000);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(contraryHoverMessage)).getText();
    }


}
