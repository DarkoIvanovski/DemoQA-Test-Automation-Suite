package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DroppablePage {

    WebDriver driver;
    WebDriverWait wait;

    public DroppablePage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String droppablePageUrl = "https://demoqa.com/droppable";

    private By acceptButton = By.id("droppableExample-tab-accept");
    private By preventPropagation = By.id("droppableExample-tab-preventPropogation");
    private By revertDraggable = By.id("droppableExample-tab-revertable");

    public void navigateToDroppablePage () {
        driver.navigate().to(droppablePageUrl);
    }

    public void simpleDroppableElement () {
        WebElement sourceElement = driver.findElement(By.id("draggable"));
        WebElement targetElement = driver.findElement(By.id("droppable"));

        Actions actions = new Actions(driver);

        actions.dragAndDrop(sourceElement, targetElement).perform();

    }

    public void clickOnAcceptButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(acceptButton)).click();
    }

    public void acceptableAndNotAcceptableElementDropIntoInner() {
        WebElement acceptable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("acceptable")));
        WebElement notAcceptable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("notAcceptable")));
        WebElement droppable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='accept-drop-container']/div[2]")));



        Actions actions = new Actions(driver);
        actions.dragAndDrop(acceptable, droppable).perform();

        if (droppable.getText().contains("Dropped!")) {
            System.out.println("Acceptable element successfully dropped.");
        } else {
            System.out.println("Acceptable element drop failed.");
        }

        actions.dragAndDrop(notAcceptable, droppable).perform();

        if (droppable.getText().contains("Drop here")) {
            System.out.println("Not acceptable element should not be dropped.");
        } else {
            System.out.println("Not acceptable element correctly not dropped.");
        }
    }

    public void clickOnPreventPropagationButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(preventPropagation)).click();
    }

    public void preventPropagation() throws InterruptedException {
        WebElement outerDroppable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("notGreedyDropBox")));
        WebElement innerDroppable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("notGreedyInnerDropBox")));
        WebElement dragMe = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dragBox")));

        Actions actions = new Actions(driver);
        actions.dragAndDrop(dragMe, innerDroppable).perform();
        Thread.sleep(500);

        if (innerDroppable.getText().contains("Dropped!")) {
            System.out.println("Drag Me element successfully dropped in inner droppable.");
        } else {
            System.out.println("Drag Me element drop failed in inner droppable.");
        }

        actions.dragAndDrop(dragMe, outerDroppable).perform();
        Thread.sleep(500);

        if (outerDroppable.getText().contains("Dropped!")) {
            System.out.println("Drag Me element successfully dropped in outer droppable.");
        } else {
            System.out.println("Drag Me element should not dropped in outer droppable.");
        }
    }

    public void clickOnRevertDraggableButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(revertDraggable)).click();
    }

    public void testRevertDraggable () throws InterruptedException {
        WebElement revertElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("revertable")));
        WebElement notRevertElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("notRevertable")));
        WebElement droppable = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='revertable-drop-container']/div[2]")));

        Actions actions = new Actions(driver);
        actions.dragAndDrop(revertElement, droppable).perform();
        Thread.sleep(3000);

        if (isElementInOriginalPosition(driver, revertElement)) {
            System.out.println("Revertible element reverted to its original position.");
        } else {
            System.out.println("Revertible element should not dropped into inner!");
                    }

        actions.dragAndDrop(notRevertElement, droppable).perform();

        if (!isElementInOriginalPosition(driver, notRevertElement)) {
            System.out.println("Not revertible element stayed in the droppable area.");
        } else {
            System.out.println("Not revertible element reverted to its original position.");
        }
    }

    private static boolean isElementInOriginalPosition(WebDriver driver, WebElement element) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        return (Boolean) js.executeScript(
                "var rect = arguments[0].getBoundingClientRect();" +
                        "var originalRect = { top: 0, left: 0 }; " + // Adjust this based on your original position
                        "return rect.top === originalRect.top && rect.left === originalRect.left;", element);
    }
}
