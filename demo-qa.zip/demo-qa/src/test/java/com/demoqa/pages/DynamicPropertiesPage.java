package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DynamicPropertiesPage {

    WebDriver driver;
    WebDriverWait wait;

    public DynamicPropertiesPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String dynamicPropertiesPageUrl = "https://demoqa.com/dynamic-properties";

    private By dynamicElement = By.xpath("//div[@class='col-12 mt-4 col-md-6']/div[2]/p");

    private By colorChangeBtn = By.id("colorChange");


    public void navigateToDynamicPropertiesPage () {
        driver.navigate().to(dynamicPropertiesPageUrl);
    }

    public void findDynamicElement () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(dynamicElement)).isDisplayed();
    }

    public void findColorChangeButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(colorChangeBtn)).isDisplayed();
    }

    public String getMessageFromColorChanged () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(colorChangeBtn)).getText();
    }
}
