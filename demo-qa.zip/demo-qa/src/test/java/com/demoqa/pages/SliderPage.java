package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SliderPage {

    WebDriver driver;
    WebDriverWait wait;

    public SliderPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String sliderPageUrl = "https://demoqa.com/slider";
    private By sliderValue = By.id("sliderValue");

    public void navigateToSliderPage () {
        driver.navigate().to(sliderPageUrl);
    }

    public void moveSlider () {
        WebElement slider = driver.findElement(By.id("sliderContainer"));
        Actions move = new Actions(driver);
        move.clickAndHold(slider)
                .moveByOffset(100, 0)
                .release()
                .perform();
    }

    public String getSliderValue () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(sliderValue)).getAttribute("value");
    }


}
