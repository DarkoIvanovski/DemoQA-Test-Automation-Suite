package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AlertsPage {

    WebDriver driver;
    WebDriverWait wait;

    public AlertsPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String alertsPageUrl = "https://demoqa.com/alerts";

    private By alertBtn = By.id("alertButton");
    private By timerAlertButton = By.id("timerAlertButton");
    private By confirmButton = By.id("confirmButton");
    private By promptButton = By.id("promtButton");
    private By messageFromConfirmButton = By.id("confirmResult");
    private By messageFromPromptButton = By.id("promptResult");


    public void navigateToAlertPage () {
        driver.navigate().to(alertsPageUrl);
    }


    public void clickOnAlertButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(alertBtn)).click();
    }

    public void clickOnTimerAlertButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(timerAlertButton)).click();
    }

    public void clickOnConfirmButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(confirmButton)).click();
    }

    public void clickOnPromptButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(promptButton)).click();
    }

    public void clickOkOnPopupMessage () {
        driver.switchTo().alert().accept();
    }
    public void clickCancelOnPopupMessage () {
        driver.switchTo().alert().dismiss();
    }
    public void sendDataOnPopupMessage (String name) {
        driver.switchTo().alert().sendKeys(name);
    }

    public String getMessageFromConfirmPopupMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(messageFromConfirmButton)).getText();
    }

    public String getMessageFromPromptButton () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(messageFromPromptButton)).getText();
    }

}
