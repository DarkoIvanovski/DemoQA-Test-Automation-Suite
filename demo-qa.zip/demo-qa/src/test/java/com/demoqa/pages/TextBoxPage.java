package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TextBoxPage {

    WebDriver driver;
    WebDriverWait wait;

    public TextBoxPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String textBoxPageUrl = "https://demoqa.com/text-box";

    private By usernameInput = By.id("userName");
    private By emailInput = By.id("userEmail");
    private By currentAddress = By.id("currentAddress");
    private By permanentAddress = By.id("permanentAddress");
    private By submitButton = By.id("submit");

    private By usernameMessage = By.xpath("//p[@id='name']");
    private By emailMessage = By.xpath("//p[@id='email']");
    private By currentAddressMessage = By.xpath("//p[@id='currentAddress']");
    private By permanentAddressMessage = By.xpath("//p[@id='permanentAddress']");


    public void navigateToTextBoxPage () {
        driver.navigate().to(textBoxPageUrl);
    }

    public void enterUsername (String username) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(usernameInput)).sendKeys(username);
    }

    public void enterEmail (String email) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailInput)).sendKeys(email);
    }

    public void enterCurrentAddress (String address1) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(currentAddress)).sendKeys(address1);
    }

    public void enterPermanentAddress (String address2) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(permanentAddress)).sendKeys(address2);
    }

    public void clickOnSubmitButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(submitButton)).click();
    }


    public String getUsernameMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(usernameMessage)).getText();
    }

    public String getEmailMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(emailMessage)).getText();
    }

    public String getCurrentAddressMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(currentAddressMessage)).getText();
    }

    public String getPermanentAddressMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(permanentAddressMessage)).getText();
    }
}
