package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class FramesPage {

    WebDriver driver;
    WebDriverWait wait;

    public FramesPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String framesPageUrl = "https://demoqa.com/frames";

    private String frame1 = "frame1";
    private String frame2 = "frame2";
    private By sampleMessage = By.id("sampleHeading");

    public void navigateToFramesPage () {
        driver.navigate().to(framesPageUrl);
    }

    public void switchToFrame1 () {
        driver.switchTo().frame(frame1);
    }

    public void switchToFrame2 () {
        driver.switchTo().frame(frame2);
    }

    public String getThisIsASamplePageMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(sampleMessage)).getText();
    }
}
