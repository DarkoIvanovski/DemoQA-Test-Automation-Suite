package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AccordionPage {

    WebDriver driver;
    WebDriverWait wait;

    public AccordionPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String accordionPageUrl = "https://demoqa.com/accordian";

    private By whatIsLoremIpsumMessage = By.xpath("//div[@id='section1Content']/p");
    private By section2Btn = By.id("section2Heading");
    private By section2firstMessage = By.xpath("//div[@id='section2Content']/p[1]");
    private By section2SecondMessage = By.xpath("//div[@id='section2Content']/p[2]");
    private By section3Btn = By.id("section3Heading");
    private By section3Message = By.xpath("//div[@id='section3Content']/p");


    public void navigateToAccordionPage() {
        driver.navigate().to(accordionPageUrl);
    }

    public String getMessageWhatIsLoremIpsum () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(whatIsLoremIpsumMessage)).getText();
    }

    public void printWhatIsLoremIpsum () {
        WebElement element = driver.findElement(whatIsLoremIpsumMessage);
        System.out.println("Lorem Ipsum is: " + element.getText());
    }

    public void clickOnSection2header () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(section2Btn)).click();
    }

    public String getMessageForWhereDoesItCome1 () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(section2firstMessage)).getText();
    }

    public String getMessageForWhereDoesItCome2 () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(section2SecondMessage)).getText();
    }

    public void clickOnSection3Header () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(section3Btn)).click();
    }

    public String getMessageForWhyDoWeUseIt () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(section3Message)).getText();
    }




}
