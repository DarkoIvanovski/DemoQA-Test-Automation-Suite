package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ModalDialogsPage {

    WebDriver driver;
    WebDriverWait wait;

    public ModalDialogsPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String modalDialogPageUrl = "https://demoqa.com/modal-dialogs";
    private By smallModalBtn = By.id("showSmallModal");
    private By largeModalBtn = By.id("showLargeModal");
    private By smallModalMessage = By.xpath("//div[@class='modal-body']");
    private By largeModalMessage = By.xpath("//div[@class='modal-content']/div[2]/p");

    public void navigateToModalDialogPage () {
        driver.navigate().to(modalDialogPageUrl);
    }

    public void clickOnSmallModalBtn() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(smallModalBtn)).click();
    }

    public void clickOnLargeModalBtn() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(largeModalBtn)).click();
    }

    public String getSmallDialogMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(smallModalMessage)).getText();
    }

    public void printSmallModalMessage () {
        WebElement element = driver.findElement(smallModalMessage);
        System.out.println("Text inside Small Modal is: " + element.getText());
    }

    public String getBigDialogMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(largeModalMessage)).getText();
    }

    public void printLargeModalMessage () {
        WebElement element = driver.findElement(largeModalMessage);
        System.out.println("Text inside Large Modal is: " + element.getText());
    }
}
