package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class BrokenImagesPage {

    WebDriver driver;
    WebDriverWait wait;

    public BrokenImagesPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String brokenImagesUrl = "https://demoqa.com/broken";

    public void navigateToBrokenImagesPage () {
        driver.navigate().to(brokenImagesUrl);
    }

    public void findBrokenImages () {
        List<WebElement> images = driver.findElements(By.tagName("img"));
        for (WebElement img : images) {
            String imgUrl = img.getAttribute("src");
            if (imgUrl !=null && !imgUrl.isEmpty()) {
                try {
                    HttpURLConnection connection = (HttpURLConnection) (new URL(imgUrl)).openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();

                    int responseCode = connection.getResponseCode();
                    if (responseCode != 200) {
                        System.out.println("Broken image found: " + imgUrl);
                    }
                } catch (IOException e) {
                    System.out.println("Exception while checking image: " + imgUrl);
                    e.printStackTrace();
                }
            } else {
                System.out.println("Image with empty or null src attribute found.");
            }
        }
    }
}
