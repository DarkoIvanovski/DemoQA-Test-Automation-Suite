package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

public class BrokenLinksPage {

    WebDriver driver;
    WebDriverWait wait;

    public BrokenLinksPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String brokenLinksPageUrl = "https://demoqa.com/broken";

    public void navigateToBrokenLinksPage () {
        driver.navigate().to(brokenLinksPageUrl);
    }

    public void findBrokenLinksInPage (){
        List<WebElement> links = driver.findElements(By.tagName("a"));

        for (WebElement link : links) {
            String linkUrl = link.getAttribute("href");

            if (linkUrl != null && !linkUrl.isEmpty()) {
                try {
                    HttpURLConnection connection = (HttpURLConnection) (new URL(linkUrl)).openConnection();
                    connection.setRequestMethod("GET");
                    connection.connect();

                    int responseCode = connection.getResponseCode();
                    if (responseCode >= 400) {
                        System.out.println("Broken link found " + linkUrl + " - Response code: " + responseCode);
                    }
                } catch (IOException e) {
                    System.out.println("Exception while checking link: " + linkUrl);
                    e.printStackTrace();
                }
            } else {
                System.out.println("Link with empty or null href attribute found.");
            }
        }
    }
}
