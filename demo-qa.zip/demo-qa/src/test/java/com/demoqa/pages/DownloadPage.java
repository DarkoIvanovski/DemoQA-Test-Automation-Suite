package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DownloadPage {

    WebDriver driver;
    WebDriverWait wait;

    public DownloadPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String uploadAndDownloadUrl = "https://demoqa.com/upload-download";

    private By downloadButton = By.id("downloadButton");

    public void navigateToUploadAndDownloadPage () {
        driver.navigate().to(uploadAndDownloadUrl);
    }

    public void clickOnDownloadButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(downloadButton)).click();
    }

}
