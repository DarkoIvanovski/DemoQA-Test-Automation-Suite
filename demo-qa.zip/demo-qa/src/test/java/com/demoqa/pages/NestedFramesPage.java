package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NestedFramesPage {

    WebDriver driver;
    WebDriverWait wait;

    public NestedFramesPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String nestedFramesPageUrl = "https://demoqa.com/nestedframes";

    public void navigateToNestedFramesPage () {
        driver.navigate().to(nestedFramesPageUrl);
    }

    public String frame1 = "frame1";

    public void switchToParentFrame () {
        driver.switchTo().frame(frame1);
    }

    public void switchToChildFrame () {
        WebElement childFrame = driver.findElement(By.xpath("//iframe[@srcdoc='<p>Child Iframe</p>']"));
        driver.switchTo().frame(childFrame);
    }

    public String getMessageFromChildFrame () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.tagName("p"))).getText();
    }

    public void printChildMessage() {
        WebElement element = driver.findElement(By.tagName("p"));
        System.out.println("Text inside child frame: " + element.getText());
    }
}
