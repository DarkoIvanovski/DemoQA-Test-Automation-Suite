package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProgressBarPage {

    WebDriver driver;
    WebDriverWait wait;

    public ProgressBarPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String progressBarPage = "https://demoqa.com/progress-bar";

    private By startAndStopButton = By.id("startStopButton");
    private By resetButton = By.id("resetButton");
    private By get100message = By.xpath("//div[@id='progressBar']/div");


    public void navigateToProgressBarPage () {
        driver.navigate().to(progressBarPage);
    }

    public void clickOnStartButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(startAndStopButton)).click();
    }

    public void clickOnResetButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(resetButton)).click();
    }

    public String getProgressBarPage100Message () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(get100message)).getText();
    }
}
