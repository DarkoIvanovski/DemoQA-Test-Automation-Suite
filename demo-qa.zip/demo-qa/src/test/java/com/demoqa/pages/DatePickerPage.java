package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;


public class DatePickerPage {

    WebDriver driver;
    WebDriverWait wait;

    public DatePickerPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String datePickerPageUrl = "https://demoqa.com/date-picker";

    private By selectYear = By.xpath("//select[@class='react-datepicker__year-select']");


    public void navigateToDatePickerPage () {
        driver.navigate().to(datePickerPageUrl);
    }

    public void clickOnDateField () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("datePickerMonthYearInput"))).click();
    }


    public void selectDay () {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement calendarField = driver.findElement(By.id("datePickerMonthYearInput"));
        calendarField.click();
        WebElement dateToSelect = driver.findElement(By.xpath("//div[@class='react-datepicker__month']/div[1]/div[4]"));
        dateToSelect.click();
    }

    public void selectMonth () {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement calendarField = driver.findElement(By.id("datePickerMonthYearInput"));
        calendarField.click();
        WebElement monthToSelect = driver.findElement(By.xpath("//select[@class='react-datepicker__month-select']/option[5]"));
        monthToSelect.click();
    }

    public void selectYear (String year) {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(selectYear));
        Select select = new Select(element);
        select.selectByValue(year);
    }

    public void selectDayInDateAndTime () {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement calendarField = driver.findElement(By.id("dateAndTimePickerInput"));
        calendarField.click();
        WebElement dateToSelect = driver.findElement(By.xpath("//div[@class='react-datepicker__month']/div[2]/div[5]"));
        dateToSelect.click();
    }

    public void selectMonthInDateAndTime (String month) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dateAndTimePickerInput"))).sendKeys(month);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dateAndTimePickerInput"))).sendKeys(Keys.ENTER);
    }

    public void selectYearInDateAndTime (String year) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dateAndTimePickerInput"))).sendKeys(year);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dateAndTimePickerInput"))).sendKeys(Keys.ENTER);
    }

    public void selectTime (String time) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dateAndTimePickerInput"))).sendKeys(time);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dateAndTimePickerInput"))).sendKeys(Keys.ENTER);
    }

}
