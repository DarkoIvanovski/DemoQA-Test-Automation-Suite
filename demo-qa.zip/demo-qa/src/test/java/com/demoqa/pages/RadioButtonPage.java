package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class RadioButtonPage {

    WebDriver driver;
    WebDriverWait wait;

    public RadioButtonPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    private String radioButtonPageUrl = "https://demoqa.com/radio-button";

    private By yesButton = By.cssSelector("label[for=yesRadio]");
    private By impressiveRadio = By.cssSelector("label[for=impressiveRadio]");
    private By getMessageFromSelectedButton = By.className("text-success");

    public void navigateToRadioButtonsPage () {
        driver.navigate().to(radioButtonPageUrl);
    }

    public void clickOnYesButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(yesButton)).click();
    }

    public void clickOnImpressiveButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(impressiveRadio)).click();
    }

    public String getMessageFromYesButton () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(getMessageFromSelectedButton)).getText();
    }

    public String getMessageFromImpressiveButton () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(getMessageFromSelectedButton)).getText();
    }

}
