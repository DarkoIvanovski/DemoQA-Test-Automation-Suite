package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ButtonsPage {

    WebDriver driver;
    WebDriverWait wait;

    public ButtonsPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String buttonsPageUrl = "https://demoqa.com/buttons";

    private By doubleClickButton = By.id("doubleClickBtn");
    private By rightClickButton = By.id("rightClickBtn");

    private By doubleClickMesage = By.id("doubleClickMessage");
    private By rightClickMessage = By.id("rightClickMessage");
    private By clickMeMessage = By.id("dynamicClickMessage");


    public void navigateToButtonsPage () {
        driver.navigate().to(buttonsPageUrl);
    }


    public void doubleClickOnButton () {
        Actions actions = new Actions(driver);
        WebElement doubleClickBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(doubleClickButton));
        actions.moveToElement(doubleClickBtn).doubleClick().build().perform();
    }

    public void rightClickOnButton () {
        Actions actions = new Actions(driver);
        WebElement contextClick = wait.until(ExpectedConditions.visibilityOfElementLocated(rightClickButton));
        actions.moveToElement(contextClick).contextClick().build().perform();
    }

    public void clickOnClickMeButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()='Click Me']"))).click();
    }

    public String getMessageFromDoubleClickButton () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(doubleClickMesage)).getText();
    }

    public String getMessageFromRightClickButton () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(rightClickMessage)).getText();
    }

    public String getMessageFromClickMeButton () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(clickMeMessage)).getText();
    }
}
