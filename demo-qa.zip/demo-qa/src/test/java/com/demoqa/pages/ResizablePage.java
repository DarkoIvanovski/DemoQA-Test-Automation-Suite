package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ResizablePage {

    WebDriver driver;
    WebDriverWait wait;

    public ResizablePage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String resizablePageUrl = "https://demoqa.com/resizable";

    public void navigateToResizablePage () {
        driver.navigate().to(resizablePageUrl);
    }

    public void resizableBoxWithRestriction() {
        WebElement resizableElement = driver.findElement(By.id("resizableBoxWithRestriction"));
        wait.until(ExpectedConditions.visibilityOf(resizableElement));

        Actions actions = new Actions(driver);
        actions.clickAndHold(resizableElement)
                .moveByOffset(400, 300)
                .release()
                .perform();

        Dimension newSize = resizableElement.getSize();
        int minWidth = 150;
        int maxWidth = 300;
        int minHeight = 150;
        int maxHeight = 500;


        assertTrue(newSize.getWidth() >= minWidth && newSize.getWidth() <= maxWidth);
        assertTrue(newSize.getHeight() >= minHeight && newSize.getHeight() <= maxHeight);
    }

    private static void assertTrue(boolean condition) {
        if (!condition) {
            throw new AssertionError("Assertion failed");
        }
    }

    public void resizableBoxWithoutRestriction() {
        WebElement resizableElement = driver.findElement(By.id("resizableBoxWithRestriction"));
        wait.until(ExpectedConditions.visibilityOf(resizableElement));

        Actions actions = new Actions(driver);
        actions.clickAndHold(resizableElement)
                .moveByOffset(300, 300)
                .release()
                .perform();

        Dimension newSize = resizableElement.getSize();
        int minWidth = 150;
        int maxWidth = 300;
        int minHeight = 150;
        int maxHeight = 500;

        assertTrue(newSize.getWidth() >= minWidth && newSize.getWidth() <= maxWidth);
        assertTrue(newSize.getHeight() >= minHeight && newSize.getHeight() <= maxHeight);
    }

}
