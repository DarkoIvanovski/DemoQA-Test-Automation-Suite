package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TabsPage {

    WebDriver driver;
    WebDriverWait wait;

    public TabsPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String tabsPageUrl = "https://demoqa.com/tabs";

    private By whatTab = By.id("demo-tab-what");
    private By originTab = By.id("demo-tab-origin");
    private By uesTab = By.id("demo-tab-use");
    private By whatMessage = By.xpath("//div[@id='demo-tabpane-what']/p");
    private By originMessageOne = By.xpath("//div[@id='demo-tabpane-origin']/p[1]");
    private By originMessageTwo = By.xpath("//div[@id='demo-tabpane-origin']/p[2]");
    private By useMessage = By.xpath("//div[@id='demo-tabpane-use']/p");

    public void navigateToTabsPage () {
        driver.navigate().to(tabsPageUrl);
    }

    public void clickOnWhatTab() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(whatTab)).click();
    }

    public String getWhatMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(whatMessage)).getText();
    }

    public void printWhatMessage () {
        System.out.println("What is Lorem Ipsum? " + wait.until(ExpectedConditions.visibilityOfElementLocated(whatMessage)).getText());
    }

    public void clickOnOriginTab() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(originTab)).click();
    }

    public String getOriginMessageOne() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(originMessageOne)).getText();
    }

    public String getOriginMessageTwo() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(originMessageTwo)).getText();
    }

    public void printOriginMessage () {
        System.out.println("Where is the origin from? " + wait.until(ExpectedConditions.visibilityOfElementLocated(originMessageOne)).getText() + wait.until(ExpectedConditions.visibilityOfElementLocated(originMessageTwo)).getText());
    }

    public void clickOnUseTab() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(uesTab)).click();
    }

    public String getUseMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(useMessage)).getText();
    }

    public void printUseMessage () {
        System.out.println("What is use of Lorem Ipsum? " + wait.until(ExpectedConditions.visibilityOfElementLocated(useMessage)).getText());
    }


}
