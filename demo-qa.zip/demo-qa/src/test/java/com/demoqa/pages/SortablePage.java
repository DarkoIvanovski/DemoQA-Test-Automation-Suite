package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SortablePage {

    WebDriver driver;
    WebDriverWait wait;

    public SortablePage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String sortablePageUrl = "https://demoqa.com/sortable";

    private By gridButton = By.id("demo-tab-grid");

    public void navigateToSortablePage () {
        driver.navigate().to(sortablePageUrl);
    }

    public void clickOnGridButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(gridButton)).click();
    }

    public void sortVerticalElement() {
        WebElement sourceElement = driver.findElement(By.xpath("//div[@id='demo-tabpane-list']/div/div[2]"));
        WebElement targetElement = driver.findElement(By.xpath("//div[@id='demo-tabpane-list']/div/div[4]"));
        Actions actions = new Actions(driver);
        actions.clickAndHold(sourceElement)
                .moveToElement(targetElement)
                .release(targetElement)
                .build()
                .perform();
    }

    public void sortGridElement() {
        WebElement sourceElement = driver.findElement(By.xpath("//div[@class='create-grid']/div[4]"));
        WebElement targetElement = driver.findElement(By.xpath("//div[@class='create-grid']/div[6]"));
        Actions actions = new Actions(driver);
        actions.clickAndHold(sourceElement)
                .moveToElement(targetElement)
                .release(targetElement)
                .build()
                .perform();
    }
}
