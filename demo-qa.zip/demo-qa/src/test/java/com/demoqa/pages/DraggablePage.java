package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DraggablePage {

    WebDriver driver;
    WebDriverWait wait;

    public DraggablePage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String dragabblePageUrl = "https://demoqa.com/dragabble";

    private By axisButton = By.id("draggableExample-tab-axisRestriction");

    private By containerButton = By.id("draggableExample-tab-containerRestriction");
    private By cursorStyleButton = By.id("draggableExample-tab-cursorStyle");

    public void navigateToDraggablePage() {
        driver.navigate().to(dragabblePageUrl);
    }

    public void testSimpleDragMeElement () {
        WebElement dragMeElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("dragBox")));

        Actions actions = new Actions(driver);

        int xOffset = 100;
        int yOffset = 50;
        actions.dragAndDropBy(dragMeElement, xOffset, yOffset).perform();
    }

    public void clickOnAxisButton () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(axisButton)).click();
        Thread.sleep(1000);
    }

    public void dragOnlyXButton () {
        WebElement dragOnlyXElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("restrictedX")));

        Actions actions = new Actions(driver);

        int xOffset = 100; // Horizontal offset
        int yOffset = 0;  // Vertical offset
        actions.dragAndDropBy(dragOnlyXElement, xOffset, yOffset).perform();
    }

    public void dragOnlyYButton () {
        WebElement dragOnlyYElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("restrictedY")));

        Actions actions = new Actions(driver);

        int xOffset = 0; // Horizontal offset
        int yOffset = 100;  // Vertical offset
        actions.dragAndDropBy(dragOnlyYElement, xOffset, yOffset).perform();
    }

    public void clickOnContainerRestrictedButton() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(containerButton)).click();
        Thread.sleep(1000);
    }

    public void testDragElementWithinContainer() {
        WebElement container = driver.findElement(By.id("containmentWrapper"));
        WebElement draggable = driver.findElement(By.xpath("//div[@id='containmentWrapper']/div"));

        int containerWidth = container.getSize().getWidth();
        int containerHeight = container.getSize().getHeight();

        int draggableWidth = draggable.getSize().getWidth();
        int draggableHeight = draggable.getSize().getHeight();

        Actions actions = new Actions(driver);

        int xOffset = containerWidth - draggableWidth - 10;
        int yOffset = containerHeight - draggableHeight - 10;

        actions.dragAndDropBy(draggable, xOffset, yOffset).perform();
    }

    public void dragElementWithinParent() {
        WebElement parentFrame = driver.findElement(By.xpath("//div[@class='draggable ui-widget-content m-3']"));
        WebElement draggableElement = driver.findElement(By.xpath("//div[@class='draggable ui-widget-content m-3']/span"));

        int parentWidth = parentFrame.getSize().getWidth();
        int parentHeight = parentFrame.getSize().getHeight();

        int draggableWidth = draggableElement.getSize().getWidth();
        int draggableHeight = draggableElement.getSize().getHeight();

        Actions actions = new Actions(driver);

        int maxXOffset = parentWidth - draggableWidth;
        int maxYOffset = parentHeight - draggableHeight;

        int xOffset = Math.min(100, maxXOffset);
        int yOffset = Math.min(50, maxYOffset);

        actions.dragAndDropBy(draggableElement, xOffset, yOffset).perform();
    }

    public void clickOnCursorStyleButton () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cursorStyleButton)).click();
        Thread.sleep(1000);
    }

    public void dragElementWithCursorOnTheCenter () {
        WebElement draggableElementWithCursorOnTheCenter = driver.findElement(By.id("cursorCenter"));

        int centerX = draggableElementWithCursorOnTheCenter.getSize().width / 2;
        int centerY = draggableElementWithCursorOnTheCenter.getSize().height / 2;

        int offsetX = 100;
        int offsetY = 50;

        Actions actions = new Actions(driver);

        actions.moveToElement(draggableElementWithCursorOnTheCenter, centerX, centerY)
                .clickAndHold()
                .moveByOffset(offsetX, offsetY)
                .release()
                .build()
                .perform();
    }

    public void dragElementWithCursorOnTheTopLeft () {
        WebElement draggableElementWithCursorOnTheTopLeft = driver.findElement(By.id("cursorTopLeft"));

        Actions actions = new Actions(driver);

        int offsetX = 10;
        int offsetY = 10;

        actions.moveToElement(draggableElementWithCursorOnTheTopLeft, offsetX, offsetY)
                .clickAndHold()
                .moveByOffset(100, 100) // Example move to a specific offset
                .release()
                .build()
                .perform();
    }

    public void dragElementWhenCursorIsAlwaysOnBottomOfTheElement () {
        WebElement draggableElementWithBottomOfTheElement = driver.findElement(By.id("cursorBottom"));

        int elementHeight = draggableElementWithBottomOfTheElement.getSize().getHeight();

        Actions actions = new Actions(driver);
        actions.moveToElement(draggableElementWithBottomOfTheElement, 0, elementHeight - 1).build().perform();
        actions.clickAndHold(draggableElementWithBottomOfTheElement).moveByOffset(100, 100).release().build().perform();
    }



}
