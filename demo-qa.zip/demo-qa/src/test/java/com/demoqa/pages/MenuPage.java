package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class MenuPage {

    WebDriver driver;
    WebDriverWait wait;

    public MenuPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String menuPageUrl = "https://demoqa.com/menu#";

    private By mainItem1 = By.xpath("//ul[@id='nav']/li[1]/a");
    private By mainItem2 = By.xpath("//ul[@id='nav']/li[2]/a");
    private By subItem1 = By.xpath("//ul[@id='nav']/li[2]/ul/li[1]/a");
    private By subItem2 = By.xpath("//ul[@id='nav']/li[2]/ul/li[2]/a");
    private By subSubList = By.xpath("//ul[@id='nav']/li[2]/ul/li[3]/a");
    private By subSubItem1 = By.xpath("//ul[@id='nav']/li[2]/ul/li[3]/ul/li/a");
    private By subSubItem2 = By.xpath("//ul[@id='nav']/li[2]/ul/li[3]/ul/li[2]/a");
    private By mainItem3 = By.xpath("//ul[@id='nav']/li[3]/a");


    public void navigateToManuPage () {
        driver.navigate().to(menuPageUrl);
    }

    public void clickOnMainItem1() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mainItem1)).click();
    }

    public void clickOnMainItem2() throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mainItem2)).click();
        Thread.sleep(3000);
    }

    public void clickOnSubItem1() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement mainMenu2 = driver.findElement(mainItem2);
        Actions actions = new Actions(driver);
        actions.moveToElement(mainMenu2).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement subMenuItem1 = driver.findElement(subItem1);
        actions.moveToElement(subMenuItem1).click().perform();
    }

    public void clickOnSubItem2() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement mainMenu2 = driver.findElement(mainItem2);
        Actions actions = new Actions(driver);
        actions.moveToElement(mainMenu2).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement subMenuItem2 = driver.findElement(subItem2);
        actions.moveToElement(subMenuItem2).click().perform();
    }

    public void clickOnSubSubList() {
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement mainMenu2 = driver.findElement(mainItem2);
        Actions actions = new Actions(driver);
        actions.moveToElement(mainMenu2).perform();

        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        WebElement subSubListMenu = driver.findElement(subSubList);
        actions.moveToElement(subSubListMenu).click().perform();
    }

    public void clickOnSubSubItem1() {
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        WebElement mainMenu2 = driver.findElement(mainItem2);
        Actions actions = new Actions(driver);
        actions.moveToElement(mainMenu2).perform();

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        WebElement subSubListMenu = driver.findElement(subSubList);
        actions.moveToElement(subSubListMenu).click().perform();

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        WebElement subSubItem1Menu = driver.findElement(subSubItem1);
        actions.moveToElement(subSubItem1Menu).click().perform();
    }

    public void clickOnSubSubItem2() {
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        WebElement mainMenu2 = driver.findElement(subItem2);
        Actions actions = new Actions(driver);
        actions.moveToElement(mainMenu2).perform();

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        WebElement subSubItemMenu = driver.findElement(subSubList);
        actions.moveToElement(subSubItemMenu).click().perform();
        
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        WebElement subSubItem2Menu = driver.findElement(subSubItem2);
        actions.moveToElement(subSubItem2Menu).click().perform();
    }

    public void clickOnMainItem3() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mainItem3)).click();
    }

}
