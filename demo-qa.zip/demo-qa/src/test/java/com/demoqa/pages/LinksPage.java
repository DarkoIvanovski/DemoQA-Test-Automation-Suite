package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LinksPage {

    WebDriver driver;
    WebDriverWait wait;

    public LinksPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String linksPageUrl = "https://demoqa.com/links";
    private By homeLink = By.id("simpleLink");
    private By dynamicLink = By.id("dynamicLink");
    private By createdLink = By.id("created");
    private By noContentLink = By.id("no-content");
    private By movedLink = By.id("moved");
    private By badRequestLink = By.id("bad-request");
    private By unauthorizedLink = By.id("unauthorized");
    private By forbiddenLink = By.id("forbidden");
    private By notFoundLink = By.id("invalid-url");
    private By linkResponse = By.id("linkResponse");

    public void navigateToLinksPage () {
        driver.navigate().to(linksPageUrl);
    }

    public void clickOnHomeLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(homeLink)).click();
    }

    public void clickOnDynamicLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(dynamicLink)).click();
    }

    public void clickOnCreatedLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(createdLink)).click();
    }

    public void clickOnNoContentLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(noContentLink)).click();
    }

    public void clickOnMovedLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(movedLink)).click();
    }

    public void clickOnBadRequestLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(badRequestLink)).click();
    }

    public void clickOnuUnauthorizedLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(unauthorizedLink)).click();
    }

    public void clickOnForbiddenLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(forbiddenLink)).click();
    }

    public void clickOnNotFoundLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(notFoundLink)).click();
    }

    public String getMessageFromLinkResponse () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(linkResponse)).getText();
    }
}
