package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


public class PracticeFormPage {

    WebDriver driver;
    WebDriverWait wait;

    public PracticeFormPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String practiceFormUrl = "https://demoqa.com/automation-practice-form";

    private By firstName = By.id("firstName");
    private By lastName = By.id("lastName");
    private By email = By.id("userEmail");
    private By male = By.cssSelector("label[for='gender-radio-1']");
    private By mobilePhone = By.id("userNumber");
    private By subject = By.id("subjectsInput");
    private By musicHobbies = By.cssSelector("label[for='hobbies-checkbox-3']");
    private By currentAddress = By.id("currentAddress");
    private By state = By.id("react-select-3-input");
    private By city = By.id("react-select-4-input");
    private By submitBtn = By.id("submit");
    private By firstNameAndLastNameMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[1]/td[2]");
    private By emailMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[2]/td[2]");
    private By ganderMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[3]/td[2]");
    private By mobilePhoneMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[4]/td[2]");
    private By subjectMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[6]/td[2]");
    private By hobbiesMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[7]/td[2]");
    private By addressMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[9]/td[2]");
    private By stateAndCityMessage = By.xpath("//div[@class='table-responsive']/table/tbody/tr[10]/td[2]");
    private By thanksForSubmittingMessage = By.id("example-modal-sizes-title-lg");

    public void navigateToPracticeFormPage () {
        driver.navigate().to(practiceFormUrl);
    }

    public void enterFirstName (String userFirstName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).sendKeys(userFirstName);
    }

    public void enterLastName (String userLastName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).sendKeys(userLastName);
    }

    public void enterEmail (String userEmail) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(email)).sendKeys(userEmail);
    }

    public void selectMaleAsGender () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(male)).click();
    }

    public void enterMobilePhone (String userMobilePhone) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(mobilePhone)).sendKeys(userMobilePhone);
    }

    public void enterSubject (String userSubject) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(subject)).sendKeys(userSubject);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(subject)).sendKeys(Keys.ENTER);
    }

    public void selectMusicAsHobbies () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(musicHobbies)).click();
    }

    public void enterCurrentAddress (String userCurrentAddress) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(currentAddress)).sendKeys(userCurrentAddress);
    }

    public void selectState(String stateInput) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(state)).sendKeys(stateInput);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(state)).sendKeys(Keys.ENTER);
    }

    public void selectCity(String cityInput) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(city)).sendKeys(cityInput);
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(city)).sendKeys(Keys.ENTER);
    }

    public void clickOnSubmitButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(submitBtn)).click();
    }

    public String getMessageForThanksForSubmitting () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(thanksForSubmittingMessage)).getText();
    }

    public String getMessageForFirstNameAndLastName () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameAndLastNameMessage)).getText();
    }

    public String getMessageForEmail () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(emailMessage)).getText();
    }

    public String getMessageForGander () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(ganderMessage)).getText();
    }

    public String getMessageForMobilePhone () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(mobilePhoneMessage)).getText();
    }

    public String getMessageForSubject () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(subjectMessage)).getText();
    }

    public String getMessageForHobbies () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(hobbiesMessage)).getText();
    }

    public String getMessageForAddress () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(addressMessage)).getText();
    }

    public String getMessageForStateAndCity () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(stateAndCityMessage)).getText();
    }

}
