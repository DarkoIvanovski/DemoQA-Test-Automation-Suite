package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;

public class BrowserWindowsPage {

    WebDriver driver;
    WebDriverWait wait;

    public BrowserWindowsPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String browserWindowsPageUrl = "https://demoqa.com/browser-windows";
    public String samplePage = "https://demoqa.com/sample";

    private By newTabButton = By.id("tabButton");
    private By newWindowButton = By.id("windowButton");
    private By newWindowMessage= By.id("messageWindowButton");

    public void navigateToBrowserWindowsPage () {
        driver.navigate().to(browserWindowsPageUrl);
    }

    public void clickOnNewTabButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(newTabButton)).click();
    }

    public void openNewTab() {
        ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
        driver.switchTo().window(tabs.get(1));
        driver.get(samplePage);
        driver.close();
    }

    public void clickOnNewWindowButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(newWindowButton)).click();
    }

    public void openLinkInNewWindowAndThenCloseNewWindow() throws InterruptedException {
        WebDriver driver2 = new ChromeDriver();
        driver2.get(samplePage);
        Thread.sleep(1000);
        driver2.quit();
    }

    public void clickOnNewWindowMessage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(newWindowMessage)).click();
    }


}
