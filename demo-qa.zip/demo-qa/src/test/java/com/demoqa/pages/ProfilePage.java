package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProfilePage {

    WebDriver driver;
    WebDriverWait wait;

    public ProfilePage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String profilePageUrl = "https://demoqa.com/profile";

    private By loginLink = By.xpath("//label[@id='notLoggin-label']/a[1]");
    private By logOutButton = By.xpath("//div[@class='text-right col-md-5 col-sm-12']/button");
    private By goToBookStoreButton = By.id("gotoStore");
    private By deleteAllBooksButton = By.xpath("//div[@class='text-right button di']/button");
    private By okOnDeleteAllUserPopUpMessage = By.id("closeSmallModal-ok");
    private By cancelOnDeleteAllUserPopUpMessage = By.id("closeSmallModal-cancel");
    private By deleteUserButton = By.xpath("//div[@class='text-center button']/button");
    private By cancelUserDelete = By.id("closeSmallModal-cancel");
    private By okUserDelete = By.id("closeSmallModal-ok");



    public void navigateToProfilePage () {
        driver.navigate().to(profilePageUrl);
    }

    public void clickOnLoginLink () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginLink)).click();
    }

    public void clickOnLogOutButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(logOutButton)).click();
    }

    public void clickOnGoToBookStoreButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(goToBookStoreButton)).click();
    }

    public void clickOnDeleteAllBooksButton () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteAllBooksButton)).click();
        Thread.sleep(1500);
    }

    public void clickCancelOnDeleteAllUserPopUpMessage () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cancelOnDeleteAllUserPopUpMessage)).click();
    }

    public void clickOkOnDeleteAllUserPopUpMessage () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(okOnDeleteAllUserPopUpMessage)).click();
        Thread.sleep(1500);
    }

    public void clickOnDeleteUser () throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteUserButton)).click();
        Thread.sleep(1500);
    }

    public void clickCancelOnUserDelete () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(cancelUserDelete)).click();
    }

    public void clickOkOnUserDelete () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(okUserDelete)).click();
    }






}
