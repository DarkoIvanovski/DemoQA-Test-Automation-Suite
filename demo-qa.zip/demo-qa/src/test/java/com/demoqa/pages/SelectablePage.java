package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class SelectablePage {

    WebDriver driver;
    WebDriverWait wait;

    public SelectablePage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String selectablePageUrl = "https://demoqa.com/selectable";

    private By gridButton = By.id("demo-tab-grid");
    private By verticalSelectableElement1 = By.xpath("//ul[@id='verticalListContainer']/li[1]");
    private By verticalSelectableElement2 = By.xpath("//ul[@id='verticalListContainer']/li[2]");
    private By verticalSelectableElement3 = By.xpath("//ul[@id='verticalListContainer']/li[3]");
    private By verticalSelectableElement4 = By.xpath("//ul[@id='verticalListContainer']/li[4]");
    private By gridSelectableElement1 = By.xpath("//div[@id='row2']/li[2]");
    private By gridSelectableElement2 = By.xpath("//div[@id='row1']/li[3]");
    private By gridSelectableElement3 = By.xpath("//div[@id='row2']/li[3]");
    private By gridSelectableElement4 = By.xpath("//div[@id='row1']/li[1]");


    public void navigateToSelectablePage () {
        driver.navigate().to(selectablePageUrl);
    }

    public void clickOnGridButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(gridButton)).click();
    }

    public void selectableVerticalElement() throws InterruptedException {
        List<WebElement> selectableElements1 = driver.findElements(verticalSelectableElement1);
        List<WebElement> selectableElements2 = driver.findElements(verticalSelectableElement2);
        List<WebElement> selectableElements3 = driver.findElements(verticalSelectableElement3);
        List<WebElement> selectableElements4 = driver.findElements(verticalSelectableElement4);
        Actions actions = new Actions(driver);
        actions.keyDown(Keys.CONTROL);
        for (WebElement element : selectableElements1) {
            actions.click(element);
        }
        for (WebElement element : selectableElements2) {
            actions.click(element);
        }
        for (WebElement element : selectableElements3) {
            actions.click(element);
        }
        for (WebElement element : selectableElements4) {
            actions.click(element);
        }
        actions.keyUp(Keys.CONTROL);
        actions.build().perform();
    }

    public String getMessageForVerticalElement1 () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(verticalSelectableElement1)).getText();
    }

    public String getMessageForVerticalElement2 () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(verticalSelectableElement2)).getText();
    }

    public String getMessageForVerticalElement3 () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(verticalSelectableElement3)).getText();
    }

    public String getMessageForVerticalElement4 () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(verticalSelectableElement4)).getText();
    }

    public void selectableGridElement () throws InterruptedException {
        List<WebElement> selectableElements1 = driver.findElements(gridSelectableElement1);
        List<WebElement> selectableElements2 = driver.findElements(gridSelectableElement2);
        List<WebElement> selectableElements3 = driver.findElements(gridSelectableElement3);
        List<WebElement> selectableElements4 = driver.findElements(gridSelectableElement4);
        Actions actions = new Actions(driver);
        actions.keyDown(Keys.CONTROL);
        for (WebElement element : selectableElements1) {
            actions.click(element);
        }
        for (WebElement element : selectableElements2) {
            actions.click(element);
        }
        for (WebElement element : selectableElements3) {
            actions.click(element);
        }
        for (WebElement element : selectableElements4) {
            actions.click(element);
        }
        actions.keyUp(Keys.CONTROL);
        actions.build().perform();
    }

    public String getGridSelectableElement1Message () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(gridSelectableElement1)).getText();
    }

    public String getGridSelectableElement2Message () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(gridSelectableElement2)).getText();
    }

    public String getGridSelectableElement3Message () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(gridSelectableElement3)).getText();
    }

    public String getGridSelectableElement4Message () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(gridSelectableElement4)).getText();
    }



}
