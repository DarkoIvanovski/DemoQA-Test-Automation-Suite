package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BookStorePage {

    WebDriver driver;
    WebDriverWait wait;

    public BookStorePage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String bookStorePageUrl = "https://demoqa.com/books";

    private By loginButton = By.id("login");

    private By searchField = By.id("searchBox");
    private By showProduct = By.xpath("//select[@aria-label='rows per page']");
    private By nextButton = By.xpath("//div[@class='-next']/button");
    private By previousButton = By.xpath("//div[@class='-previous']/button");
    private By fiveRowsMessage = By.xpath("//select[@aria-label='rows per page']/option[1]");
    private By twentyRowsMessage = By.xpath("//select[@aria-label='rows per page']/option[3]");
    private By imageHeader = By.xpath("//div[@class='rt-tr']/div[1]");
    private By titleHeader = By.xpath("//div[@class='rt-tr']/div[2]");
    private By authorHeader = By.xpath("//div[@class='rt-tr']/div[3]");
    private By publisherHeader = By.xpath("//div[@class='rt-tr']/div[4]");
    private By imageResize = By.xpath("//div[@class='rt-tr']/div[1]/div[2]");
    private By titleResize = By.xpath("//div[@class='rt-tr']/div[2]/div[2]");
    private By authorResize = By.xpath("//div[@class='rt-tr']/div[3]/div[2]");
    private By publisherResize = By.xpath("//div[@class='rt-tr']/div[4]/div[2]");


    public void navigateToBookStorePage () {
        driver.navigate().to(bookStorePageUrl);
    }


    public void clickOnLoginButton(){
        wait.until(ExpectedConditions.visibilityOfElementLocated(loginButton)).click();
    }

    public void enterDataInSearchField(String search) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchField)).sendKeys(search);
    }

    public void clearDataInSearchField() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchField)).clear();
    }

    public void selectProductRow(String value) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(showProduct));
        Select select = new Select(element);
        select.selectByValue(value);
    }

    public String getFiveRowsMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(fiveRowsMessage)).getText();
    }

    public void clickOnNextButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(nextButton)).click();
    }

    public void clickOnPreviousButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(previousButton)).click();
    }

    public String getTwentyRowsMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(twentyRowsMessage)).getText();
    }

    public void orderAscendingAndDescendingByImage () {
        Actions actions = new Actions(driver);
        WebElement doubleClickBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(imageHeader));
        actions.moveToElement(doubleClickBtn).doubleClick().build().perform();
    }

    public void orderAscendingAndDescendingByTitle () {
        Actions actions = new Actions(driver);
        WebElement doubleClickBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(titleHeader));
        actions.moveToElement(doubleClickBtn).doubleClick().build().perform();
    }

    public void orderAscendingAndDescendingByAuthor () {
        Actions actions = new Actions(driver);
        WebElement doubleClickBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(authorHeader));
        actions.moveToElement(doubleClickBtn).doubleClick().build().perform();
    }

    public void orderAscendingAndDescendingByPublisher () {
        Actions actions = new Actions(driver);
        WebElement doubleClickBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(publisherHeader));
        actions.moveToElement(doubleClickBtn).doubleClick().build().perform();
    }

    public void dragImageResize () {
        WebElement dragMeElement = wait.until(ExpectedConditions.visibilityOfElementLocated(imageResize));
        Actions actions = new Actions(driver);
        int xOffset = 0;
        int yOffset = 10;
        actions.dragAndDropBy(dragMeElement, xOffset, yOffset).perform();
    }

    public void dragTitleResize () {
        WebElement dragMeElement = wait.until(ExpectedConditions.visibilityOfElementLocated(titleResize));
        Actions actions = new Actions(driver);
        int xOffset = 0;
        int yOffset = 10;
        actions.dragAndDropBy(dragMeElement, xOffset, yOffset).perform();
    }

    public void dragAuthorResize () {
        WebElement dragMeElement = wait.until(ExpectedConditions.visibilityOfElementLocated(authorResize));
        Actions actions = new Actions(driver);
        int xOffset = 0;
        int yOffset = 10;
        actions.dragAndDropBy(dragMeElement, xOffset, yOffset).perform();
    }

    public void dragPublisherResize () {
        WebElement dragMeElement = wait.until(ExpectedConditions.visibilityOfElementLocated(publisherResize));
        Actions actions = new Actions(driver);
        int xOffset = 0;
        int yOffset = 10;
        actions.dragAndDropBy(dragMeElement, xOffset, yOffset).perform();
    }


}
