package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SelectMenuPage {

    WebDriver driver;
    WebDriverWait wait;

    public SelectMenuPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String selectManuPageUrl = "https://demoqa.com/select-menu";

    private By selectValueMenu = By.id("react-select-2-input");
    private By getSelectValueMenuMessage = By.xpath("//div[@id='withOptGroup']/div/div[1]/div");
    private By selectOneMenu = By.id("react-select-3-input");
    private By getSelectOneMenuMessage = By.xpath("//div[@id='selectOne']/div/div[1]/div[1]");
    private By oldStyleMenu = By.id("oldSelectMenu");
    private By oldStyleOptionMessage = By.xpath("//select[@id='oldSelectMenu']/option[2]");
    private By multiselectDropDownMenu = By.id("react-select-4-input");
    private By standardMultiselectMenu = By.id("cars");

    public void navigateToSelectManuPage() {
        driver.navigate().to(selectManuPageUrl);
    }

    public void selectOptionOnSelectValueMenu(String option) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectValueMenu)).sendKeys(option);
        Thread.sleep(2000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectValueMenu)).sendKeys(Keys.ENTER);
    }

    public String getMessageFromSelectValueMenu() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(getSelectValueMenuMessage)).getText();
    }

    public void selectOptionOnSelectOneMenu(String option) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectOneMenu)).sendKeys(option);
        Thread.sleep(2000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(selectOneMenu)).sendKeys(Keys.ENTER);
    }

    public String getMessageFromSelectOneMenu() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(getSelectOneMenuMessage)).getText();
    }

    public void selectOldStyleMenu(String value) {
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(oldStyleMenu));
        Select select = new Select(element);
        select.selectByValue(value);
    }

    public String getOldStyleOptionMessage() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(oldStyleOptionMessage)).getText();
    }

    public void populateMultiSelectInput(String[] inputs) throws InterruptedException {
        for (int i = 0; i < inputs.length; i++) {
            wait.until(ExpectedConditions.visibilityOfElementLocated(multiselectDropDownMenu)).sendKeys(inputs[i]);
            Thread.sleep(500);
            wait.until(ExpectedConditions.visibilityOfElementLocated(multiselectDropDownMenu)).sendKeys(Keys.ENTER);
        }
    }

    public void populateStandardMultiselectInput() {
        WebElement multiSelectElement = driver.findElement(standardMultiselectMenu);
        Select multiSelect = new Select(multiSelectElement);
        if (multiSelect.isMultiple()) {
            multiSelect.selectByValue("volvo");
            multiSelect.selectByValue("saab");
            multiSelect.selectByValue("opel");
            multiSelect.selectByValue("audi");
        } else {
            System.out.println("The select element is not a multi-select");
        }
    }
}
