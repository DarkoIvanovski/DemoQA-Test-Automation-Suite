package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CheckBoxPage {

    WebDriver driver;
    WebDriverWait wait;

    public CheckBoxPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }


    private String checkBoxPageUrl = "https://demoqa.com/checkbox";

    private By homeCheckBox = By.xpath("//span[@class='rct-checkbox']");
    private By plusBtn = By.xpath("//button[@class='rct-option rct-option-expand-all']");
    private By workSpaceBtn = By.xpath("//label[@for='tree-node-workspace']");
    private By wordBtn = By.xpath("//label[@for='tree-node-wordFile']");
    private By homeCheckBoxMessage = By.xpath("//div[@id='result']/span[2]");
    private By desktopChecBoxMessage = By.xpath("//div[@id='result']/span[2]");
    private By workspaceCheckBoxMessage = By.xpath("//div[@id='result']/span[5]");
    private By classifiedCheckBoxSelected = By.xpath("//div[@id='result']/span[9]");
    private By wordFileCheckBoxSelected = By.xpath("//div[@id='result']/span[10]");
    private By minusBtn = By.xpath("//button[@title='Collapse all']");


    public void navigateToCheckBoxPage () {
        driver.navigate().to(checkBoxPageUrl);
    }
    public void clickOnHomeCheckBoxButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(homeCheckBox)).click();
    }
    public void clickOnPlusButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(plusBtn)).click();
    }
    public void clickOnDesktopButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[@for='tree-node-desktop']"))).click();
    }
    public void clickOnWorkSpaceButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(workSpaceBtn)).click();
    }
    public void clickOnClassifiedButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//label[@for='tree-node-classified']"))).click();
    }
    public void clickOnWordButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(wordBtn)).click();
    }


    public String getMessageFromHomeCheckBoxSelected() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(homeCheckBoxMessage)).getText();
    }

    public String getMessageFromDesktopCheckBoxSelected() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(desktopChecBoxMessage)).getText();
    }

    public String getMessageFromWorkspaceCheckBoxSelected() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(workspaceCheckBoxMessage)).getText();
    }

    public String getMessageFromClassifiedCheckBoxSelected() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(classifiedCheckBoxSelected)).getText();
    }

    public String getMessageFromWordFileCheckBoxSelected() {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(wordFileCheckBoxSelected)).getText();
    }

    public void clickOnMinusButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(minusBtn)).click();
    }

    public void uncheckButton () {
        Actions actions = new Actions(driver);
        WebElement doubleClickBtn = wait.until(ExpectedConditions.visibilityOfElementLocated(homeCheckBox));
        actions.moveToElement(doubleClickBtn).doubleClick().build().perform();
    }

    public String isCheckBoxUnselected(){
        return wait.until(ExpectedConditions.visibilityOfElementLocated(homeCheckBox)).getAttribute("class");
    }


}
