package com.demoqa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class WebTablesPage {

    WebDriver driver;
    WebDriverWait wait;

    public WebTablesPage (WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
    }

    public String webTablesPageUrl = "https://demoqa.com/webtables";


    private By addBtn = By.id("addNewRecordButton");
    private By firstName = By.id("firstName");
    private By lastName = By.id("lastName");
    private By email = By.id("userEmail");
    private By age = By.id("age");
    private By salary = By.id("salary");
    private By department = By.id("department");
    private By submitButton = By.xpath("//button[@id='submit']");
    private By editBtn = By.id("edit-record-4");
    private By deleteBtn = By.id("delete-record-4");
    private By firstNameTable = By.xpath("//div[@class='ReactTable -striped -highlight']/div/div/div/div[1]");
    private By lastNameTable = By.xpath("//div[@class='ReactTable -striped -highlight']/div/div/div/div[2]");
    private By ageInTable = By.xpath("//div[@class='ReactTable -striped -highlight']/div/div/div/div[3]");
    private By emailTable = By.xpath("//div[@class='ReactTable -striped -highlight']/div/div/div/div[4]");
    private By salaryTable = By.xpath("//div[@class='ReactTable -striped -highlight']/div/div/div/div[5]");
    private By departmentTable = By.xpath("//div[@class='ReactTable -striped -highlight']/div/div/div/div[6]");
    private By rowsInTable = By.xpath("//select[@aria-label='rows per page']");
    private By searchField = By.id("searchBox");

    private By firstNameMessage = By.xpath("//div[@class='rt-tbody']/div[4]/div/div[1]");
    private By lastNameMessage = By.xpath("//div[@class='rt-tbody']/div[4]/div/div[2]");
    private By ageMessage = By.xpath("//div[@class='rt-tbody']/div[4]/div/div[3]");
    private By emailMessage = By.xpath("//div[@class='rt-tbody']/div[4]/div/div[4]");
    private By salaryMessage = By.xpath("//div[@class='rt-tbody']/div[4]/div/div[5]");
    private By departmentMessage = By.xpath("//div[@class='rt-tbody']/div[4]/div/div[6]");



    public void navigateToWebTablesPage() {
        driver.navigate().to(webTablesPageUrl);
    }

    public void clickOnAddButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(addBtn)).click();
    }

    public void enterFirstName (String firstNameUser) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).sendKeys(firstNameUser);
    }

    public void enterLastName (String lastNameUser) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).sendKeys(lastNameUser);
    }

    public void enterEmail (String emailUser) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(email)).sendKeys(emailUser);
    }

    public void enterAge (String ageUser) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(age)).sendKeys(ageUser);
    }

    public void enterSalary (String salaryUser) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(salary)).sendKeys(salaryUser);
    }

    public void enterDepartment (String departmentUser) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(department)).sendKeys(departmentUser);
    }

    public void clickOnSubmitButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(submitButton)).click();
    }

    public void clickOnEditButton () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(editBtn)).click();
    }

    public void editFirstName (String firstNameUser) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstName)).sendKeys(firstNameUser);
    }

    public void editLastName (String lastNameUser) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastName)).sendKeys(lastNameUser);
    }

    public void editUserEmail (String userEmail) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(email)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(email)).sendKeys(userEmail);
    }

    public void editUserAge (String userAge) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(age)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(age)).sendKeys(userAge);
    }

    public void editUserSalary (String userSalary) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(salary)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(salary)).sendKeys(userSalary);
    }

    public void editUserDepartment (String userDepartment) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(department)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(department)).sendKeys(userDepartment);
    }

    public void deleteUser () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(deleteBtn)).click();
    }

    public void orderTableByFirstName () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameTable)).click();
    }

    public void orderTableByLastName () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameTable)).click();
    }

    public void orderTableByAge () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(ageInTable)).click();
    }

    public void orderTableByEmail () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(emailTable)).click();
    }

    public void orderTableBySalary () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(salaryTable)).click();
    }

    public void orderTableByDepartment () {
        wait.until(ExpectedConditions.visibilityOfElementLocated(departmentTable)).click();
    }

    public void selectRowsInTable (String value){
        WebElement element = wait.until(ExpectedConditions.visibilityOfElementLocated(rowsInTable));
        Select select = new Select(element);
        select.selectByValue(value);
    }

    public String getMessageForRowsInTable () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//select[@aria-label='rows per page']/option[5]"))).getText();
    }

    public void enterDataInSearchField (String data) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchField)).sendKeys(data);
    }

    public void editDataInSearchField (String data) throws InterruptedException {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchField)).clear();
        Thread.sleep(500);
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchField)).sendKeys(data);
    }

    public String getFirstNameMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(firstNameMessage)).getText();
    }

    public String getLastNameMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(lastNameMessage)).getText();
    }

    public String getAgeMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(ageMessage)).getText();
    }

    public String getEmailMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(emailMessage)).getText();
    }

    public String getSalaryMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(salaryMessage)).getText();
    }

    public String getDepartmentMessage () {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(departmentMessage)).getText();
    }



}
