package com.demoqa.tests;

import org.testng.annotations.Test;

public class SortableTests extends BaseTest {

    @Test
    public void testVerticalSortableElement () {
        sortablePage.navigateToSortablePage();
        js.executeScript("window.scrollBy(0, 200)","");
        sortablePage.sortVerticalElement();
    }

    @Test
    public void testGridSortableElement () throws InterruptedException {
        sortablePage.navigateToSortablePage();
        sortablePage.clickOnGridButton();
        js.executeScript("window.scrollBy(0, 400)","");
        Thread.sleep(3000);
        sortablePage.sortGridElement();
    }
}
