package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SliderTests extends BaseTest {

    @Test
    public void testSliderPage () throws InterruptedException {
        sliderPage.navigateToSliderPage();
        sliderPage.moveSlider();
        Thread.sleep(1500);
        boolean isSliderValue88 = sliderPage.getSliderValue().contains("88");
        Assert.assertTrue(isSliderValue88, "Checking if value is 88");
    }
}
