package com.demoqa.tests;

import com.demoqa.utils.DataForWebTables;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class WebTablesTests extends BaseTest {

    @Test
    public void enterNewUser () {
        webTablesPage.navigateToWebTablesPage();
        webTablesPage.clickOnAddButton();
        webTablesPage.enterFirstName("Ana");
        webTablesPage.enterLastName("Jovanovska");
        webTablesPage.enterEmail("ana.jovanovski@yahoo.com");
        webTablesPage.enterAge("29");
        webTablesPage.enterSalary("62000");
        webTablesPage.enterDepartment("Marketing");
        webTablesPage.clickOnSubmitButton();

        Assert.assertEquals(webTablesPage.getFirstNameMessage(), "Ana");
        Assert.assertEquals(webTablesPage.getLastNameMessage(), "Jovanovska");
        Assert.assertEquals(webTablesPage.getEmailMessage(), "ana.jovanovski@yahoo.com");
        Assert.assertEquals(webTablesPage.getAgeMessage(),"29");
        Assert.assertEquals(webTablesPage.getSalaryMessage(), "62000");
        Assert.assertEquals(webTablesPage.getDepartmentMessage(), "Marketing");
    }

    @Test
    public void editUser () throws InterruptedException {
        webTablesPage.navigateToWebTablesPage();
        js.executeScript("window.scrollBy(0, 500)","");
        webTablesPage.clickOnAddButton();
        webTablesPage.enterFirstName("Marko");
        webTablesPage.enterLastName("Petreski");
        webTablesPage.enterEmail("marko.petreski@gmail.com");
        webTablesPage.enterAge("34");
        webTablesPage.enterSalary("75000");
        webTablesPage.enterDepartment("IT");
        webTablesPage.clickOnSubmitButton();
        js.executeScript("window.scrollBy(0, 500)","");
        Thread.sleep(500);
        webTablesPage.clickOnEditButton();
        webTablesPage.editFirstName("Ivana");
        webTablesPage.editLastName("Stefanovska");
        webTablesPage.editUserEmail("ivana.stefanovska@yahoo.com");
        webTablesPage.editUserAge("27");
        webTablesPage.editUserSalary("58000");
        webTablesPage.editUserDepartment("Human Resources");
        webTablesPage.clickOnSubmitButton();

        Assert.assertEquals(webTablesPage.getFirstNameMessage(), "Ivana");
        Assert.assertEquals(webTablesPage.getLastNameMessage(), "Stefanovska");
        Assert.assertEquals(webTablesPage.getEmailMessage(), "ivana.stefanovska@yahoo.com");
        Assert.assertEquals(webTablesPage.getAgeMessage(),"27");
        Assert.assertEquals(webTablesPage.getSalaryMessage(), "58000");
        Assert.assertEquals(webTablesPage.getDepartmentMessage(), "Human Resources");
    }

    @Test
    public void deleteUser () throws InterruptedException {
        webTablesPage.navigateToWebTablesPage();
        webTablesPage.clickOnAddButton();
        webTablesPage.enterFirstName("Nikola");
        webTablesPage.enterLastName("Kovacevski");
        webTablesPage.enterEmail("nikola.kovacevski@yahoo.com");
        webTablesPage.enterAge("31");
        webTablesPage.enterSalary("68000");
        webTablesPage.enterDepartment("Finance");
        webTablesPage.clickOnSubmitButton();
        js.executeScript("window.scrollBy(0, 500)","");
        Thread.sleep(500);
        webTablesPage.deleteUser();
    }

    @Test
    public void testOtherFunctionalitiesInWebTables () throws InterruptedException {
        webTablesPage.navigateToWebTablesPage();
        js.executeScript("window.scrollBy(0, 500)","");
        webTablesPage.orderTableByFirstName();
        webTablesPage.orderTableByLastName();
        webTablesPage.orderTableByAge();
        webTablesPage.orderTableByEmail();
        webTablesPage.orderTableBySalary();
        webTablesPage.orderTableByDepartment();
        webTablesPage.selectRowsInTable("50");
        Assert.assertEquals(webTablesPage.getMessageForRowsInTable(), "50 rows");
        webTablesPage.enterDataInSearchField("Cierra");
        webTablesPage.editDataInSearchField("Vega");
    }

    @Test (dataProvider = "data-for-webtables", dataProviderClass = DataForWebTables.class)
    public void testWebTablesWithDataProvider (String firstName, String lastName, String email, String age, String salary, String department) {
        webTablesPage.navigateToWebTablesPage();
        webTablesPage.clickOnAddButton();
        webTablesPage.enterFirstName(firstName);
        webTablesPage.enterLastName(lastName);
        webTablesPage.enterEmail(email);
        webTablesPage.enterAge(age);
        webTablesPage.enterSalary(salary);
        webTablesPage.enterDepartment(department);
        webTablesPage.clickOnSubmitButton();
    }
}
