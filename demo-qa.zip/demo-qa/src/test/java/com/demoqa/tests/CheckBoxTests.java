package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class CheckBoxTests extends BaseTest {

    @Test
    public void testHomeCheckBox () {
        checkBoxPage.navigateToCheckBoxPage();
        checkBoxPage.clickOnHomeCheckBoxButton();
        Assert.assertEquals(checkBoxPage.getMessageFromHomeCheckBoxSelected(), "home");
    }

    @Test
    public void testUncheckOption () {
        checkBoxPage.navigateToCheckBoxPage();
        checkBoxPage.uncheckButton();

        boolean isCheckBoxSelected = checkBoxPage.isCheckBoxUnselected().contains("check");
        Assert.assertTrue(isCheckBoxSelected, "Checking if check box is unselected");
    }

    @Test
    public void testMultipleCheckBoxes () throws InterruptedException {
        checkBoxPage.navigateToCheckBoxPage();
        checkBoxPage.clickOnPlusButton();
        Thread.sleep(1500);
        js.executeScript("window.scrollBy(0, 500)","");
        checkBoxPage.clickOnDesktopButton();
        Assert.assertEquals(checkBoxPage.getMessageFromDesktopCheckBoxSelected(), "desktop");
        checkBoxPage.clickOnWorkSpaceButton();
        Assert.assertEquals(checkBoxPage.getMessageFromWorkspaceCheckBoxSelected(), "workspace");
        js.executeScript("window.scrollBy(0, 500)","");
        checkBoxPage.clickOnClassifiedButton();
        Assert.assertEquals(checkBoxPage.getMessageFromClassifiedCheckBoxSelected(), "classified");
        checkBoxPage.clickOnWordButton();
        Assert.assertEquals(checkBoxPage.getMessageFromWordFileCheckBoxSelected(), "wordFile");
        checkBoxPage.clickOnMinusButton();
    }

}
