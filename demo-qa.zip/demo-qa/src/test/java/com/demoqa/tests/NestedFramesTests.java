package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class NestedFramesTests extends BaseTest {

    @Test
    public void testNestedFrames () {
        nestedFramesPage.navigateToNestedFramesPage();
        js.executeScript("window.scrollBy(0, 500)","");
        nestedFramesPage.switchToParentFrame();
        nestedFramesPage.switchToChildFrame();
        Assert.assertEquals(nestedFramesPage.getMessageFromChildFrame(), "Child Iframe");
        nestedFramesPage.printChildMessage();
    }
}
