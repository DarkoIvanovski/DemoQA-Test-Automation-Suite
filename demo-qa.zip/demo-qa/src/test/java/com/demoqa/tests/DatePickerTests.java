package com.demoqa.tests;

import org.testng.annotations.Test;

public class DatePickerTests extends BaseTest {

    @Test
    public void testDateField () throws InterruptedException {
        datePickerPage.navigateToDatePickerPage();
        datePickerPage.clickOnDateField();
        datePickerPage.selectDay();
        datePickerPage.selectMonth();
        datePickerPage.selectYear("1990");
        Thread.sleep(3000);
    }

    @Test
    public void testDateAndTime () throws InterruptedException {
        datePickerPage.navigateToDatePickerPage();
        js.executeScript("window.scrollBy(0, 500)","");
        datePickerPage.selectDayInDateAndTime();
        datePickerPage.selectMonthInDateAndTime("August");
        datePickerPage.selectYearInDateAndTime("1995");
        datePickerPage.selectTime("02:45");
    }
}
