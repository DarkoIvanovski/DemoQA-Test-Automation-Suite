package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SelectMenuTests extends BaseTest {

    @Test
    public void testSelectValueMenu () throws InterruptedException {
        selectMenuPage.navigateToSelectManuPage();
        selectMenuPage.selectOptionOnSelectValueMenu("Group 2, option 1");
        Assert.assertEquals(selectMenuPage.getMessageFromSelectValueMenu(), "Group 2, option 1");
    }

    @Test
    public void testSelectOneMenu () throws InterruptedException {
        selectMenuPage.navigateToSelectManuPage();
        js.executeScript("window.scrollBy(0, 500)","");
        selectMenuPage.selectOptionOnSelectOneMenu("Mr.");
        Assert.assertEquals(selectMenuPage.getMessageFromSelectOneMenu(), "Mr.");
        Thread.sleep(3000);
    }

    @Test
    public void testOldStyleMenu () {
        selectMenuPage.navigateToSelectManuPage();
        js.executeScript("window.scrollBy(0, 1000)","");
        selectMenuPage.selectOldStyleMenu("2");
        Assert.assertEquals(selectMenuPage.getOldStyleOptionMessage(), "Blue");
    }


    private String [] colors = {"Blue", "Green", "Black", "Red"};

    @Test
    public void testMultiselectDropDownMenu () throws InterruptedException {
        selectMenuPage.navigateToSelectManuPage();
        js.executeScript("window.scrollBy(0, 1000)","");
        selectMenuPage.populateMultiSelectInput(colors);
    }


    @Test
    public void testStandardMultiSelectMenu () {
        selectMenuPage.navigateToSelectManuPage();
        js.executeScript("window.scrollBy(0, 1000)","");
        selectMenuPage.populateStandardMultiselectInput();
    }


}
