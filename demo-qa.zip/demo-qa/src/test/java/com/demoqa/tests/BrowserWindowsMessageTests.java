package com.demoqa.tests;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;

public class BrowserWindowsMessageTests extends BaseTest {

    @Test
    public void testNewTabButton () {
        browserWindowsPage.navigateToBrowserWindowsPage();
        browserWindowsPage.clickOnNewTabButton();
        ((JavascriptExecutor) driver).executeScript("window.open()");
        browserWindowsPage.openNewTab();
    }

    @Test
    public void testNewWindowButton () throws InterruptedException {
        browserWindowsPage.navigateToBrowserWindowsPage();
        browserWindowsPage.clickOnNewWindowButton();
        browserWindowsPage.openLinkInNewWindowAndThenCloseNewWindow();
    }

    @Test
    public void testNewWindowMessage () {
        browserWindowsPage.navigateToBrowserWindowsPage();
        browserWindowsPage.clickOnNewWindowMessage();
    }
}
