package com.demoqa.tests;

import org.testng.annotations.Test;

public class BrokenImagesTests extends BaseTest {

    @Test
    public void testBrokenImagesPage () {
        brokenImagesPage.navigateToBrokenImagesPage();
        brokenImagesPage.findBrokenImages();
    }
}
