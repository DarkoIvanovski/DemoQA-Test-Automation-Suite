package com.demoqa.tests;

import org.testng.annotations.Test;

public class MenuTests extends BaseTest {

    @Test
    public void testMenuPage () throws InterruptedException {
        menuPage.navigateToManuPage();
        js.executeScript("window.scrollBy(0, 500)","");
        menuPage.clickOnMainItem1();
        menuPage.clickOnMainItem2();
        js.executeScript("window.scrollBy(0, 500)","");
        menuPage.clickOnSubItem1();
        js.executeScript("window.scrollBy(0, 500)","");
        menuPage.clickOnSubItem2();
        js.executeScript("window.scrollBy(0, 500)","");
        menuPage.clickOnSubSubList();
        js.executeScript("window.scrollBy(0, 500)","");
        menuPage.clickOnSubSubItem1();
        js.executeScript("window.scrollBy(0, 500)","");
        menuPage.clickOnSubSubItem2();
        js.executeScript("window.scrollBy(0, 500)","");
        menuPage.clickOnMainItem3();
    }
}
