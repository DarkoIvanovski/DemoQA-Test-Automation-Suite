package com.demoqa.tests;

import com.demoqa.pages.*;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import java.time.Duration;

public class BaseTest {

    public WebDriver driver;
    public WebDriverWait wait;

    JavascriptExecutor js;

    private int duration = 10;

    final String BASE_URL = "https://demoqa.com/";

    public TextBoxPage textBoxPage;
    public CheckBoxPage checkBoxPage;
    public RadioButtonPage radioButtonPage;
    public WebTablesPage webTablesPage;
    public ButtonsPage buttonsPage;
    public LinksPage linksPage;
    public BrokenImagesPage brokenImagesPage;
    public BrokenLinksPage brokenLinksPage;
    public DownloadPage downloadPage;
    public DynamicPropertiesPage dynamicPropertiesPage;
    public PracticeFormPage practiceFormPage;
    public BrowserWindowsPage browserWindowsPage;
    public AlertsPage alertsPage;
    public FramesPage framesPage;
    public NestedFramesPage nestedFramesPage;
    public ModalDialogsPage modalDialogsPage;
    public AccordionPage accordionPage;
    public AutoCompletePage autoCompletePage;
    public DatePickerPage datePickerPage;
    public SliderPage sliderPage;
    public ProgressBarPage progressBarPage;
    public TabsPage tabsPage;
    public ToolsTipPage toolsTipPage;
    public MenuPage menuPage;
    public SelectMenuPage selectMenuPage;
    public SortablePage sortablePage;
    public SelectablePage selectablePage;
    public ResizablePage resizablePage;
    public DroppablePage droppablePage;
    public DraggablePage draggablePage;
    public LoginPage loginPage;
    public BookStorePage bookStorePage;
    public ProfilePage profilePage;


    @BeforeMethod
    public void setUp () {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized","--incognito", "--headless");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(duration));
        driver.get(BASE_URL);
        textBoxPage = new TextBoxPage (driver, wait);
        checkBoxPage = new CheckBoxPage (driver, wait);
        radioButtonPage = new RadioButtonPage (driver, wait);
        webTablesPage = new WebTablesPage (driver, wait);
        buttonsPage = new ButtonsPage (driver, wait);
        linksPage = new LinksPage (driver, wait);
        brokenImagesPage = new BrokenImagesPage (driver, wait);
        brokenLinksPage = new BrokenLinksPage (driver, wait);
        downloadPage = new DownloadPage(driver, wait);
        dynamicPropertiesPage = new DynamicPropertiesPage (driver, wait);
        practiceFormPage = new PracticeFormPage (driver, wait);
        browserWindowsPage = new BrowserWindowsPage (driver, wait);
        alertsPage = new  AlertsPage (driver, wait);
        framesPage = new FramesPage (driver, wait);
        nestedFramesPage = new NestedFramesPage (driver, wait);
        modalDialogsPage = new ModalDialogsPage (driver, wait);
        accordionPage = new AccordionPage(driver, wait);
        autoCompletePage = new AutoCompletePage (driver, wait);
        datePickerPage = new DatePickerPage (driver, wait);
        sliderPage = new SliderPage (driver, wait);
        progressBarPage = new ProgressBarPage (driver, wait);
        tabsPage = new TabsPage (driver, wait);
        toolsTipPage = new ToolsTipPage (driver, wait);
        menuPage = new MenuPage (driver, wait);
        selectMenuPage = new SelectMenuPage (driver, wait);
        sortablePage = new SortablePage (driver, wait);
        selectablePage = new SelectablePage (driver, wait);
        resizablePage = new ResizablePage (driver, wait);
        droppablePage = new DroppablePage (driver, wait);
        draggablePage = new DraggablePage(driver, wait);
        loginPage = new LoginPage (driver, wait);
        bookStorePage = new BookStorePage (driver, wait);
        profilePage = new ProfilePage (driver, wait);
        js = (JavascriptExecutor) driver;
        driver.manage().window().maximize();
    }

    @AfterMethod
    public void tearDown () {
        driver.quit();
    }
}
