package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class PracticeFormTests extends BaseTest {

    @Test
    public void testPracticeFormPage () throws InterruptedException {
        practiceFormPage.navigateToPracticeFormPage();
        js.executeScript("window.scrollBy(0, 1000)","");
        practiceFormPage.enterFirstName("John");
        practiceFormPage.enterLastName("Smith");
        practiceFormPage.enterEmail("john.smith456@example.com");
        practiceFormPage.selectMaleAsGender();
        practiceFormPage.enterMobilePhone("0123456789");
        js.executeScript("window.scrollBy(0, 500)","");
        practiceFormPage.selectMusicAsHobbies();
        practiceFormPage.enterSubject("Computer Science");
        practiceFormPage.enterCurrentAddress("456 Oak Avenue, Anytown, CA 90210, USA");
        practiceFormPage.selectState("NCR");
        practiceFormPage.selectCity("Delhi");
        js.executeScript("window.scrollBy(0, 500)","");
        practiceFormPage.clickOnSubmitButton();

        Assert.assertEquals(practiceFormPage.getMessageForThanksForSubmitting(), "Thanks for submitting the form");
        Assert.assertEquals(practiceFormPage.getMessageForFirstNameAndLastName(), "John Smith");
        Assert.assertEquals(practiceFormPage.getMessageForEmail(), "john.smith456@example.com");
        Assert.assertEquals(practiceFormPage.getMessageForGander(), "Male");
        Assert.assertEquals(practiceFormPage.getMessageForMobilePhone(), "0123456789");
        Assert.assertEquals(practiceFormPage.getMessageForSubject(), "Computer Science");
        Assert.assertEquals(practiceFormPage.getMessageForHobbies(), "Music");
        Assert.assertEquals(practiceFormPage.getMessageForAddress(), "456 Oak Avenue, Anytown, CA 90210, USA");
        Assert.assertEquals(practiceFormPage.getMessageForStateAndCity(), "NCR Delhi");
    }
}
