package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ButtonsTests extends BaseTest {

    @Test
    public void testButtonsPage () {
        buttonsPage.navigateToButtonsPage();
        js.executeScript("window.scrollBy(0, 500)","");
        buttonsPage.doubleClickOnButton();
        Assert.assertEquals(buttonsPage.getMessageFromDoubleClickButton(), "You have done a double click");
        buttonsPage.rightClickOnButton();
        Assert.assertEquals(buttonsPage.getMessageFromRightClickButton(), "You have done a right click");
        buttonsPage.clickOnClickMeButton();
        Assert.assertEquals(buttonsPage.getMessageFromClickMeButton(), "You have done a dynamic click");
    }
}
