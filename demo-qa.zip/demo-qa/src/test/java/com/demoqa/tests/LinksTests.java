package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class LinksTests extends BaseTest {

    @Test
    public void testOpenLinksInNewTabs () throws InterruptedException {
        linksPage.navigateToLinksPage();
        js.executeScript("window.scrollBy(0, 1500)", "");
        linksPage.clickOnHomeLink();
        linksPage.clickOnDynamicLink();
    }

    @Test
    public void testLinksAndApiCalls () throws InterruptedException {
        linksPage.navigateToLinksPage();
        js.executeScript("window.scrollBy(0, 1500)", "");
        linksPage.clickOnCreatedLink();
        Assert.assertEquals(linksPage.getMessageFromLinkResponse(), "Link has responded with staus 201 and status text Created");
        linksPage.clickOnNoContentLink();
        Thread.sleep(500);
        Assert.assertEquals(linksPage.getMessageFromLinkResponse(), "Link has responded with staus 204 and status text No Content");
        linksPage.clickOnMovedLink();
        Thread.sleep(500);
        Assert.assertEquals(linksPage.getMessageFromLinkResponse(), "Link has responded with staus 301 and status text Moved Permanently");
        linksPage.clickOnBadRequestLink();
        Thread.sleep(500);
        Assert.assertEquals(linksPage.getMessageFromLinkResponse(), "Link has responded with staus 400 and status text Bad Request");
        linksPage.clickOnuUnauthorizedLink();
        Thread.sleep(500);
        Assert.assertEquals(linksPage.getMessageFromLinkResponse(), "Link has responded with staus 401 and status text Unauthorized");
        linksPage.clickOnForbiddenLink();
        Thread.sleep(500);
        Assert.assertEquals(linksPage.getMessageFromLinkResponse(), "Link has responded with staus 403 and status text Forbidden");
        linksPage.clickOnNotFoundLink();
        Thread.sleep(500);
        Assert.assertEquals(linksPage.getMessageFromLinkResponse(), "Link has responded with staus 404 and status text Not Found");
    }
}
