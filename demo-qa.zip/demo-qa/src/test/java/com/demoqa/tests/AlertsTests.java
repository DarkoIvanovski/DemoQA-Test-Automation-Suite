package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class AlertsTests extends BaseTest {

    @Test
    public void testClickButtonToSeeAlert () {
        alertsPage.navigateToAlertPage();
        js.executeScript("window.scrollBy(0, 500)","");
        alertsPage.clickOnAlertButton();
        alertsPage.clickOkOnPopupMessage();
    }

    @Test
    public void testTimeAlertButton () throws InterruptedException {
        alertsPage.navigateToAlertPage();
        js.executeScript("window.scrollBy(0, 500)","");
        alertsPage.clickOnTimerAlertButton();
        Thread.sleep(5000);
        alertsPage.clickOkOnPopupMessage();
    }

    @Test
    public void testConfirmButton () {
        alertsPage.navigateToAlertPage();
        js.executeScript("window.scrollBy(0, 500)","");
        alertsPage.clickOnConfirmButton();
        alertsPage.clickOkOnPopupMessage();
        Assert.assertEquals(alertsPage.getMessageFromConfirmPopupMessage(), "You selected Ok");
        alertsPage.clickOnConfirmButton();
        alertsPage.clickCancelOnPopupMessage();
        Assert.assertEquals(alertsPage.getMessageFromConfirmPopupMessage(), "You selected Cancel");
    }

    @Test
    public void testPromptBox () {
        alertsPage.navigateToAlertPage();
        js.executeScript("window.scrollBy(0, 500)","");
        alertsPage.clickOnPromptButton();
        alertsPage.sendDataOnPopupMessage("Alessio");
        alertsPage.clickOkOnPopupMessage();
        Assert.assertEquals(alertsPage.getMessageFromPromptButton(), "You entered Alessio");
    }
}
