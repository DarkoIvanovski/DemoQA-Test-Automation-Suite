package com.demoqa.tests;

import org.testng.annotations.Test;

public class BrokenLinksTests extends BaseTest {

    @Test
    public void testBrokenLinksPage () {
        brokenLinksPage.navigateToBrokenLinksPage();
        brokenLinksPage.findBrokenLinksInPage();
    }
}
