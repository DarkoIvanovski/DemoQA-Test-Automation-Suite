package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class EndToEndUserRegistrationProfileAndDelete extends BaseTest {

    @Test
    public void testEndToEndUserRegistrationProfileAndDelete () throws InterruptedException {
        loginPage.navigateToLoginPage();
        js.executeScript("window.scrollBy(0, 500)","");
        loginPage.clickOnNewUserButton();
        loginPage.enterFirstName("Jessica");
        loginPage.enterLastName("Taylor");
        loginPage.enterUserName("JessicaT2024");
        loginPage.enterLoginPassword("T@yl0rJ!");
        Thread.sleep(30000);    // Manually solve reCAPTCHA
        loginPage.clickOnRegisterButton();
        Thread.sleep(2000);
        alertsPage.clickOkOnPopupMessage();
        loginPage.clickOnBackToLogin();
        js.executeScript("window.scrollBy(0, 500)","");
        loginPage.enterUserName("JessicaT2024");
        loginPage.enterPassword("T@yl0rJ!");
        loginPage.clickLogin();
        Assert.assertEquals(loginPage.getUserNameMessage(),"JessicaT2024");
        js.executeScript("window.scrollBy(0, 800)","");
        profilePage.clickOnDeleteUser();
        profilePage.clickOkOnUserDelete();
        Thread.sleep(1500);
        alertsPage.clickOkOnPopupMessage();
    }
}
