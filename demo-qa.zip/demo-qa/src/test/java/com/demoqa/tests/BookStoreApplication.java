package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class BookStoreApplication extends BaseTest {

    @Test
    public void testLoginPageWithNewUserRegistration () throws InterruptedException {
        loginPage.navigateToLoginPage();
        js.executeScript("window.scrollBy(0,500)", "");
        loginPage.clickOnNewUserButton();
        loginPage.enterFirstName("Sarah");
        loginPage.enterLastName("Wilson");
        loginPage.enterUserName("sarahwilson");
        loginPage.enterPassword("S@rahW1ls");
        Thread.sleep(50000);        // Solve manual reCAPTCHA
        loginPage.clickOnRegisterButton();
        Thread.sleep(3000);
        loginPage.clickOkOnPopupMessage();
        Thread.sleep(3000);
        loginPage.clickOnBackToLogin();
    }

    @Test
    public void testLoginPageWithSignInOption () {
        loginPage.navigateToLoginPage();
        js.executeScript("window.scrollBy(0,500)", "");
        loginPage.enterLoginUserName("sarahwilson");
        loginPage.enterLoginPassword("S@rahW1ls");
        loginPage.clickLogin();
        Assert.assertEquals(loginPage.getUserNameMessage(), "sarahwilson");
    }

    @Test
    public void testBookStorePage () throws InterruptedException {
        bookStorePage.navigateToBookStorePage();
        js.executeScript("window.scrollBy(0, 300)","");
        bookStorePage.clickOnLoginButton();
        loginPage.enterLoginUserName("sarahwilson");
        loginPage.enterLoginPassword("S@rahW1ls");
        Thread.sleep(1500);
        bookStorePage.navigateToBookStorePage();
        js.executeScript("window.scrollBy(0, 500)","");
        bookStorePage.enterDataInSearchField("java");
        bookStorePage.clearDataInSearchField();
        bookStorePage.selectProductRow("5");
        Assert.assertEquals(bookStorePage.getFiveRowsMessage(),"5 rows");
        bookStorePage.clickOnNextButton();
        bookStorePage.clickOnPreviousButton();
        Assert.assertEquals(bookStorePage.getTwentyRowsMessage(),"20 rows");
        bookStorePage.orderAscendingAndDescendingByImage();
        bookStorePage.orderAscendingAndDescendingByTitle();
        bookStorePage.orderAscendingAndDescendingByAuthor();
        bookStorePage.orderAscendingAndDescendingByPublisher();
        bookStorePage.dragImageResize();
        bookStorePage.dragTitleResize();
        bookStorePage.dragAuthorResize();
        bookStorePage.dragPublisherResize();
    }

    @Test
    public void testProfilePageWithLoginAndLogOut () throws InterruptedException {
        profilePage.navigateToProfilePage();
        js.executeScript("window.scrollBy(0, 300)","");
        profilePage.clickOnLoginLink();
        loginPage.navigateToLoginPage();
        loginPage.enterLoginUserName("sarahwilson");
        loginPage.enterLoginPassword("S@rahW1ls");
        js.executeScript("window.scrollBy(0, 300)","");
        loginPage.clickLogin();
        Thread.sleep(2000);
        profilePage.navigateToProfilePage();
        Thread.sleep(2000);
        profilePage.clickOnLogOutButton();
    }

    @Test
    public void testProfilePageWithLogInAndGoToBookStore () throws InterruptedException {
        profilePage.navigateToProfilePage();
        js.executeScript("window.scrollBy(0, 300)","");
        profilePage.clickOnLoginLink();
        loginPage.navigateToLoginPage();
        js.executeScript("window.scrollBy(0, 300)","");
        loginPage.enterLoginUserName("sarahwilson");
        loginPage.enterLoginPassword("S@rahW1ls");
        loginPage.clickLogin();
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0, 500)","");
        profilePage.clickOnGoToBookStoreButton();
        bookStorePage.navigateToBookStorePage();
        Thread.sleep(2000);
    }

    @Test
    public void testProfilePageWithDeleteAllBooks () throws InterruptedException {
        profilePage.navigateToProfilePage();
        js.executeScript("window.scrollBy(0, 500)","");
        profilePage.clickOnLoginLink();
        loginPage.navigateToLoginPage();
        js.executeScript("window.scrollBy(0, 300)","");
        loginPage.enterLoginUserName("sarahwilson");
        loginPage.enterLoginPassword("S@rahW1ls");
        loginPage.clickLogin();
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0, 800)","");
        profilePage.clickOnDeleteAllBooksButton();
        profilePage.clickCancelOnDeleteAllUserPopUpMessage();
        profilePage.clickOkOnDeleteAllUserPopUpMessage();
        alertsPage.clickOkOnPopupMessage();
    }

    @Test
    public void testProfilePageWithDeleteUser () throws InterruptedException {
        profilePage.navigateToProfilePage();
        js.executeScript("window.scrollBy(0, 500)","");
        profilePage.clickOnLoginLink();
        loginPage.navigateToLoginPage();
        js.executeScript("window.scrollBy(0, 300)","");
        loginPage.enterLoginUserName("sarahwilson");
        loginPage.enterLoginPassword("S@rahW1ls");
        loginPage.clickLogin();
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0, 800)","");
        profilePage.clickOnDeleteUser();
        profilePage.clickCancelOnUserDelete();
        profilePage.clickOkOnUserDelete();
        Thread.sleep(1500);
        alertsPage.clickOkOnPopupMessage();
    }

    @Test
    public void testEndToEndUserRegistrationProfileAndDelete () throws InterruptedException {
        loginPage.navigateToLoginPage();
        js.executeScript("window.scrollBy(0, 500)","");
        loginPage.clickOnNewUserButton();
        loginPage.enterFirstName("Jessica");
        loginPage.enterLastName("Taylor");
        loginPage.enterUserName("JessicaJT2024");
        loginPage.enterLoginPassword("T@yl0rJ!");
        Thread.sleep(30000);    // Manually solve reCAPTCHA
        loginPage.clickOnRegisterButton();
        Thread.sleep(2000);
        alertsPage.clickOkOnPopupMessage();
        loginPage.clickOnBackToLogin();
        js.executeScript("window.scrollBy(0, 500)","");
        loginPage.enterUserName("JessicaJT2024");
        loginPage.enterPassword("T@yl0rJ!");
        loginPage.clickLogin();
        Assert.assertEquals(loginPage.getUserNameMessage(),"JessicaJT2024");
        js.executeScript("window.scrollBy(0, 800)","");
        profilePage.clickOnDeleteUser();
        profilePage.clickOkOnUserDelete();
        Thread.sleep(1500);
        alertsPage.clickOkOnPopupMessage();
    }
}
