package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ProgressBarTests extends BaseTest {

    @Test
    public void testProgressbarPage () throws InterruptedException {
        progressBarPage.navigateToProgressBarPage();
        js.executeScript("window.scrollBy(0, 200)","");
        progressBarPage.clickOnStartButton();
        Thread.sleep(10000);
        Assert.assertEquals(progressBarPage.getProgressBarPage100Message(),"100%");
        progressBarPage.clickOnResetButton();
    }
}
