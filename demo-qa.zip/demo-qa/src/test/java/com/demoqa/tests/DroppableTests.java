package com.demoqa.tests;

import org.testng.annotations.Test;

public class DroppableTests extends BaseTest {

    @Test
    public void testSimpleDroppableElement () {
        droppablePage.navigateToDroppablePage();
        droppablePage.simpleDroppableElement();
    }

    @Test
    public void testAcceptableElement () throws InterruptedException {
        droppablePage.navigateToDroppablePage();
        droppablePage.clickOnAcceptButton();
        Thread.sleep(3000);
        droppablePage.acceptableAndNotAcceptableElementDropIntoInner();
    }

    @Test
    public void testPreventPropagation() throws InterruptedException {
        droppablePage.navigateToDroppablePage();
        droppablePage.clickOnPreventPropagationButton();
        Thread.sleep(1500);
        js.executeScript("window.scrollBy(0, 1500)","");
        droppablePage.preventPropagation();
    }

    @Test
    public void testRevertDraggableElement () throws InterruptedException {
        droppablePage.navigateToDroppablePage();
        droppablePage.clickOnRevertDraggableButton();
        Thread.sleep(1500);
        js.executeScript("window.scrollBy(0, 200)","");
        droppablePage.testRevertDraggable();
    }
}
