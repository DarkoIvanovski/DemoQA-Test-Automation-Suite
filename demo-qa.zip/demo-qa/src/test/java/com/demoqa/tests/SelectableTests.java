package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class SelectableTests extends BaseTest {

    @Test
    public void testVerticalSelectableElement () throws InterruptedException {
        selectablePage.navigateToSelectablePage();
        js.executeScript("window.scrollBy(0, 500)","");
        selectablePage.selectableVerticalElement();
        Thread.sleep(3000);

        Assert.assertEquals(selectablePage.getMessageForVerticalElement1(), "Cras justo odio");
        Assert.assertEquals(selectablePage.getMessageForVerticalElement2(), "Dapibus ac facilisis in");
        Assert.assertEquals(selectablePage.getMessageForVerticalElement3(), "Morbi leo risus");
        Assert.assertEquals(selectablePage.getMessageForVerticalElement4(), "Porta ac consectetur ac");
    }

    @Test
    public void testGridSelectableElement () throws InterruptedException {
        selectablePage.navigateToSelectablePage();
        js.executeScript("window.scrollBy(0, 500)","");
        selectablePage.clickOnGridButton();
        selectablePage.selectableGridElement();

        Assert.assertEquals(selectablePage.getGridSelectableElement1Message(), "Five");
        Assert.assertEquals(selectablePage.getGridSelectableElement2Message(), "Three");
        Assert.assertEquals(selectablePage.getGridSelectableElement3Message(), "Six");
        Assert.assertEquals(selectablePage.getGridSelectableElement4Message(), "One");
    }
}
