package com.demoqa.tests;

import org.testng.annotations.Test;

public class AutoCompleteTests extends BaseTest {

    @Test
    public void testMultipleColorField () {
        autoCompletePage.navigateToAutoCompletePage();
        js.executeScript("window.scrollBy(0, 500)","");
        autoCompletePage.enterMultipleColor();
    }

    @Test
    public void testSingleColorField () {
        autoCompletePage.navigateToAutoCompletePage();
        js.executeScript("window.scrollBy(0, 500)","");
        autoCompletePage.enterSingleColor("Blue");
    }
}
