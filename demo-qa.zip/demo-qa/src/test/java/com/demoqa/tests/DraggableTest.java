package com.demoqa.tests;

import org.testng.annotations.Test;

public class DraggableTest extends BaseTest {

    @Test
    public void testSimpleDraggableElement () {
        draggablePage.navigateToDraggablePage();
        draggablePage.testSimpleDragMeElement();
    }

    @Test
    public void testJustXElementDragInHorizontal () throws InterruptedException {
        draggablePage.navigateToDraggablePage();
        draggablePage.clickOnAxisButton();
        js.executeScript("window.scrollBy(0, 200)","");
        draggablePage.dragOnlyXButton();
    }

    @Test
    public void testJustYElementDragInVertical () throws InterruptedException {
        draggablePage.navigateToDraggablePage();
        draggablePage.clickOnAxisButton();
        js.executeScript("window.scrollBy(0, 200)","");
        draggablePage.dragOnlyYButton();
    }

    @Test
    public void testDraggableElementWithinTheBox () throws InterruptedException {
        draggablePage.navigateToDraggablePage();
        draggablePage.clickOnContainerRestrictedButton();
        js.executeScript("window.scrollBy(0, 200)", "");
        draggablePage.testDragElementWithinContainer();
    }

    @Test
    public void testDraggableElementWithinParent () throws InterruptedException {
        draggablePage.navigateToDraggablePage();
        draggablePage.clickOnContainerRestrictedButton();
        js.executeScript("window.scrollBy(0, 500)", "");
        draggablePage.dragElementWithinParent();
    }

    @Test
    public void testDraggableElementWithCursorInTheCenter () throws InterruptedException {
        draggablePage.navigateToDraggablePage();
        draggablePage.clickOnCursorStyleButton();
        js.executeScript("window.scrollBy(0, 500)", "");
        draggablePage.dragElementWithCursorOnTheCenter();
    }

    @Test
    public void testDraggableElementWithCursorInTheTopLeft () throws InterruptedException {
        draggablePage.navigateToDraggablePage();
        draggablePage.clickOnCursorStyleButton();
        js.executeScript("window.scrollBy(0, 500)", "");
        draggablePage.dragElementWithCursorOnTheTopLeft();
    }

    @Test
    public void testDraggableElementWithCursorAtTheBottom () throws InterruptedException {
        draggablePage.navigateToDraggablePage();
        draggablePage.clickOnCursorStyleButton();
        js.executeScript("window.scrollBy(0, 500)", "");
        draggablePage.dragElementWhenCursorIsAlwaysOnBottomOfTheElement();
    }
}
