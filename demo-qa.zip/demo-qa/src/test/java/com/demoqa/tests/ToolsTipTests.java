package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ToolsTipTests extends BaseTest {

    @Test
    public void testButtonHover () throws InterruptedException {
        toolsTipPage.navigateToToolsTipPage();
        js.executeScript("window.scrollBy(0, 500)","");
        toolsTipPage.overWithButton();
        Assert.assertEquals(toolsTipPage.getMessageWhenOverOnButton(), "You hovered over the Button");
    }

    @Test
    public void testHoverField () throws InterruptedException {
        toolsTipPage.navigateToToolsTipPage();
        js.executeScript("window.scrollBy(0, 1000)","");
        toolsTipPage.overWithField();
        Assert.assertEquals(toolsTipPage.getMessageWhenOverOnField(), "You hovered over the text field");
    }

    @Test
    public void testHoverText () throws InterruptedException {
        toolsTipPage.navigateToToolsTipPage();
        Thread.sleep(2000);
        js.executeScript("window.scrollBy(0,1200)","");
        toolsTipPage.overWithText();
        Assert.assertEquals(toolsTipPage.getMessageWhenOverOnText(), "You hovered over the Contrary");
    }
}
