package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class FramesTests extends BaseTest {

    @Test
    public void testFrame1 () {
        framesPage.navigateToFramesPage();
        js.executeScript("window.scrollBy(0, 500)","");
        framesPage.switchToFrame1();
        Assert.assertEquals(framesPage.getThisIsASamplePageMessage(), "This is a sample page");
    }

    @Test
    public void testFrame2 () {
        framesPage.navigateToFramesPage();
        js.executeScript("window.scrollBy(0, 500)","");
        framesPage.switchToFrame2();
        Assert.assertEquals(framesPage.getThisIsASamplePageMessage(), "This is a sample page");
    }
}
