package com.demoqa.tests;

import org.testng.annotations.Test;

public class DownloadTests extends BaseTest {

    @Test
    public void testDownloadButton () {
        downloadPage.navigateToUploadAndDownloadPage();
        downloadPage.clickOnDownloadButton();
    }

}
