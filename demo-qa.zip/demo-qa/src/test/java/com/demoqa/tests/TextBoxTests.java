package com.demoqa.tests;

import com.demoqa.utils.DataForTextBoxPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TextBoxTests extends BaseTest {

    @Test
    public void testTextBoxPage () {
        textBoxPage.navigateToTextBoxPage();
        textBoxPage.enterUsername("ForestWanderer99");
        textBoxPage.enterEmail("forestwanderer99@example.com");
        textBoxPage.enterCurrentAddress("852 Cherry Blossom Lane, Portland, OR 97205");
        textBoxPage.enterPermanentAddress("147 Evergreen Terrace, Seattle, WA 98101");
        js.executeScript("window.scrollBy(0, 500)","");
        textBoxPage.clickOnSubmitButton();

        Assert.assertEquals(textBoxPage.getUsernameMessage(), "Name:ForestWanderer99");
        Assert.assertEquals(textBoxPage.getEmailMessage(), "Email:forestwanderer99@example.com");
        Assert.assertEquals(textBoxPage.getCurrentAddressMessage(), "Current Address :852 Cherry Blossom Lane, Portland, OR 97205");
        Assert.assertEquals(textBoxPage.getPermanentAddressMessage(), "Permananet Address :147 Evergreen Terrace, Seattle, WA 98101");
    }

    @Test (dataProvider = "data-for-text-box-input", dataProviderClass = DataForTextBoxPage.class)
    public void testTextBoxWithDataProvider (String username, String email, String currentAddress, String permanentAddress) {
        textBoxPage.navigateToTextBoxPage();
        textBoxPage.enterUsername(username);
        textBoxPage.enterEmail(email);
        textBoxPage.enterCurrentAddress(currentAddress);
        textBoxPage.enterPermanentAddress(permanentAddress);
        js.executeScript("window.scrollBy(0, 500)","");
        textBoxPage.clickOnSubmitButton();
    }

}
