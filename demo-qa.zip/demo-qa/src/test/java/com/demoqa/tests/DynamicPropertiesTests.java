package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DynamicPropertiesTests extends BaseTest {

    @Test
    public void findDynamicElement () {
        dynamicPropertiesPage.navigateToDynamicPropertiesPage();
        dynamicPropertiesPage.findDynamicElement();
    }

    @Test
    public void findColorChangedAfter5Sec () throws InterruptedException {
        dynamicPropertiesPage.navigateToDynamicPropertiesPage();
        js.executeScript("window.scrollBy(0, 500)","");
        Thread.sleep(6000);
        dynamicPropertiesPage.findColorChangeButton();
        Assert.assertEquals(dynamicPropertiesPage.getMessageFromColorChanged(), "Color Change");
    }
}
