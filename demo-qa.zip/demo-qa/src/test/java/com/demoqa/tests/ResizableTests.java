package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class ResizableTests extends BaseTest {

    @Test
    public void testResizableBox() throws InterruptedException {
        resizablePage.navigateToResizablePage();
        js.executeScript("window.scrollBy(0, 300)","");
        resizablePage.resizableBoxWithRestriction();
        Thread.sleep(1500);
    }

    @Test
    public void testResizableWindow () throws InterruptedException {
        resizablePage.navigateToResizablePage();
        js.executeScript("window.scrollBy(0, 700)", "");
        Thread.sleep(1500);
        resizablePage.resizableBoxWithoutRestriction();
        Thread.sleep(3000);
    }


}
