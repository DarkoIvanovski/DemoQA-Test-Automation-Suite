package com.demoqa.tests;

import org.testng.Assert;
import org.testng.annotations.Test;

public class RadioButtonTests extends BaseTest {

    @Test
    public void testRadioButtonPage () {
        radioButtonPage.navigateToRadioButtonsPage();
        radioButtonPage.clickOnYesButton();
        Assert.assertEquals(radioButtonPage.getMessageFromYesButton(), "Yes");
        radioButtonPage.clickOnImpressiveButton();
        Assert.assertEquals(radioButtonPage.getMessageFromImpressiveButton(), "Impressive");
    }
}
